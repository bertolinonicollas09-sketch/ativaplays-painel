/* AtivaPlays TV — versão LEVE para TV (LG webOS, Samsung Tizen e navegadores).
   Mesma cara e mesmas funções do app (Flutter), feita em HTML/CSS/JS puro para
   rodar liso no processador fraco de uma TV.

   COMO ELE FICA RÁPIDO:
   1) Nada de framework: cada tela é HTML simples.
   2) Carrosséis carregam aos poucos (fileira só busca quando chega perto da
      tela; 30 capas por vez).
   3) O controle remoto não mede a tela inteira a cada tecla: dentro de uma
      fileira/lista anda pelo vizinho direto.
   4) Nada de vídeo tocando escondido atrás dos menus.

   JavaScript "antigo" (var, function, XMLHttpRequest) de propósito: roda
   também nas TVs de 2016-2018.

   Tudo passa pela Edge Function `lista_proxy` (Supabase): usuário e senha da
   lista nunca chegam à TV. */
(function () {
  'use strict';

  var CFG = window.ATIVA_CONFIG || {};
  var API = (CFG.SUPABASE_URL || '').replace(/\/+$/, '') + '/functions/v1/lista_proxy';
  var PAGE = 30;
  var LIST_PAGE = 60;
  var SUPORTE = 'WhatsApp +55 11 98510-8317';

  // ================================================================ atalhos
  function $(id) { return document.getElementById(id); }
  function qs(sel, root) { return (root || document).querySelector(sel); }
  function qsa(sel, root) { return (root || document).querySelectorAll(sel); }
  function list(nodes) { var a = [], i; for (i = 0; i < nodes.length; i++) { a.push(nodes[i]); } return a; }
  function has(el, cls) { return !!el && !!el.classList && el.classList.contains(cls); }
  function on(el, cls) { if (el && el.classList) { el.classList.add(cls); } }
  function off(el, cls) { if (el && el.classList) { el.classList.remove(cls); } }
  function text(el, t) { if (el) { el.textContent = t == null ? '' : String(t); } }
  function clear(el) { while (el && el.firstChild) { el.removeChild(el.firstChild); } }
  function mk(tag, cls, txt) {
    var e = document.createElement(tag);
    if (cls) { e.className = cls; }
    if (txt != null) { e.textContent = txt; }
    return e;
  }
  function two(n) { return (n < 10 ? '0' : '') + n; }
  function clock(secs) {
    secs = Math.max(0, Math.floor(secs || 0));
    var h = Math.floor(secs / 3600), m = Math.floor((secs % 3600) / 60), s = secs % 60;
    return (h > 0 ? h + ':' : '') + two(m) + ':' + two(s);
  }

  var toastTimer = 0;
  function toast(msg) {
    var t = $('toast');
    text(t, msg);
    on(t, 'on');
    if (toastTimer) { clearTimeout(toastTimer); }
    toastTimer = setTimeout(function () { off(t, 'on'); }, 3200);
  }

  // ================================================================ ícones
  var ICONS = {
    tv: '<rect x="3" y="7" width="18" height="13" rx="2"/><path d="M8 3l4 4 4-4"/>',
    film: '<rect x="3" y="3" width="18" height="18" rx="2"/><path d="M7 3v18M17 3v18M3 8h4M3 16h4M17 8h4M17 16h4"/>',
    layers: '<path d="M12 3l9 5-9 5-9-5 9-5z"/><path d="M3 13l9 5 9-5"/>',
    clock: '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
    heart: '<path d="M20.8 5.6a5.5 5.5 0 0 0-7.8 0L12 6.7l-1-1.1a5.5 5.5 0 0 0-7.8 7.8l1 1.1L12 22l7.8-7.5 1-1.1a5.5 5.5 0 0 0 0-7.8z"/>',
    gear: '<circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.7 1.7 0 0 0 .3 1.8l.1.1a2 2 0 1 1-2.8 2.8l-.1-.1a1.7 1.7 0 0 0-1.8-.3 1.7 1.7 0 0 0-1 1.5V21a2 2 0 0 1-4 0v-.1a1.7 1.7 0 0 0-1.1-1.5 1.7 1.7 0 0 0-1.8.3l-.1.1a2 2 0 1 1-2.8-2.8l.1-.1a1.7 1.7 0 0 0 .3-1.8 1.7 1.7 0 0 0-1.5-1H3a2 2 0 0 1 0-4h.1a1.7 1.7 0 0 0 1.5-1.1 1.7 1.7 0 0 0-.3-1.8l-.1-.1a2 2 0 1 1 2.8-2.8l.1.1a1.7 1.7 0 0 0 1.8.3H9a1.7 1.7 0 0 0 1-1.5V3a2 2 0 0 1 4 0v.1a1.7 1.7 0 0 0 1 1.5 1.7 1.7 0 0 0 1.8-.3l.1-.1a2 2 0 1 1 2.8 2.8l-.1.1a1.7 1.7 0 0 0-.3 1.8V9a1.7 1.7 0 0 0 1.5 1H21a2 2 0 0 1 0 4h-.1a1.7 1.7 0 0 0-1.5 1z"/>',
    refresh: '<path d="M21 12a9 9 0 0 1-15.5 6.2L3 16"/><path d="M3 12A9 9 0 0 1 18.5 5.8L21 8"/><path d="M21 3v5h-5M3 21v-5h5"/>',
    search: '<circle cx="11" cy="11" r="7"/><path d="M21 21l-4.3-4.3"/>',
    play: '<path d="M7 4l13 8-13 8z" fill="currentColor"/>',
    pause: '<path d="M7 4h4v16H7zM13 4h4v16h-4z" fill="currentColor"/>',
    grid: '<rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/>',
    user: '<circle cx="12" cy="8" r="4"/><path d="M4 21c1.5-4 4.5-6 8-6s6.5 2 8 6"/>',
    lock: '<rect x="4" y="11" width="16" height="10" rx="2"/><path d="M8 11V7a4 4 0 0 1 8 0v4"/>',
    family: '<circle cx="8" cy="7" r="3"/><circle cx="17" cy="9" r="2.5"/><path d="M3 21c.5-4 2.5-6 5-6s4.5 2 5 6M13 21c.4-3 1.8-4.5 4-4.5s3.6 1.5 4 4.5"/>',
    block: '<circle cx="12" cy="12" r="9"/><path d="M5.6 5.6l12.8 12.8"/>',
    palette: '<path d="M12 3a9 9 0 1 0 0 18c1 0 1.5-.7 1.5-1.5 0-.4-.2-.8-.4-1.1-.3-.3-.4-.6-.4-1 0-.8.7-1.5 1.5-1.5H16a5 5 0 0 0 5-5c0-4.4-4-7.9-9-7.9z"/><circle cx="7.5" cy="11" r="1"/><circle cx="10" cy="7" r="1"/><circle cx="15" cy="7" r="1"/>',
    cloud: '<path d="M7 18a5 5 0 0 1-.6-10 6 6 0 0 1 11.5 2A4 4 0 0 1 17 18z"/>',
    history: '<path d="M3 12a9 9 0 1 0 3-6.7L3 8"/><path d="M3 3v5h5M12 7v5l3 2"/>',
    folder: '<path d="M3 6a2 2 0 0 1 2-2h4l2 2h8a2 2 0 0 1 2 2v10a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/>',
    info: '<circle cx="12" cy="12" r="9"/><path d="M12 11v6M12 7.5v.5"/>',
    back: '<path d="M19 12H5M11 18l-6-6 6-6"/>',
    key: '<circle cx="8" cy="15" r="4"/><path d="M11 12l9-9M17 6l3 3"/>',
    chip: '<rect x="6" y="6" width="12" height="12" rx="2"/><path d="M9 2v4M15 2v4M9 18v4M15 18v4M2 9h4M2 15h4M18 9h4M18 15h4"/>',
    list: '<path d="M8 6h13M8 12h13M8 18h13M3 6h.01M3 12h.01M3 18h.01"/>',
    check: '<path d="M20 6L9 17l-5-5"/>',
    prev: '<path d="M6 5v14"/><path d="M19 5L9 12l10 7z" fill="currentColor"/>',
    next: '<path d="M18 5v14"/><path d="M5 5l10 7-10 7z" fill="currentColor"/>',
    hd: '<rect x="3" y="5" width="18" height="14" rx="2"/><path d="M7 9v6M7 12h3M10 9v6M14 9h1.5a2.5 2.5 0 0 1 0 5H14z"/>',
    chat: '<path d="M21 12a8 8 0 0 1-11.6 7.1L4 20l1-4.6A8 8 0 1 1 21 12z"/>',
    power: '<path d="M12 3v9M6.3 6.3a8 8 0 1 0 11.4 0"/>'
  };
  function ico(name) { return '<svg class="ico" viewBox="0 0 24 24" aria-hidden="true">' + (ICONS[name] || '') + '</svg>'; }
  function paintIcons(root) {
    var els = list(qsa('[data-ico]', root)), i;
    for (i = 0; i < els.length; i++) {
      if (els[i]._ico) { continue; }
      els[i]._ico = true;
      els[i].insertAdjacentHTML('afterbegin', ico(els[i].getAttribute('data-ico')));
    }
  }

  // ================================================================ memória local
  var mem = {};
  var store = {
    get: function (k) {
      try { var v = window.localStorage.getItem(k); return v === null ? (k in mem ? mem[k] : null) : v; }
      catch (e) { return k in mem ? mem[k] : null; }
    },
    set: function (k, v) { mem[k] = v; try { window.localStorage.setItem(k, v); } catch (e) {} },
    del: function (k) { delete mem[k]; try { window.localStorage.removeItem(k); } catch (e) {} }
  };
  function getJson(k, fallback) {
    var raw = store.get(k);
    if (!raw) { return fallback; }
    try { var v = JSON.parse(raw); return v === null ? fallback : v; } catch (e) { return fallback; }
  }
  function setJson(k, v) { try { store.set(k, JSON.stringify(v)); } catch (e) {} }

  // ================================================================ configurações
  var DEF = {
    quality: 'best', failover: true, failWait: 15, resumeLast: false, infoBar: 5, format: 'hls',
    clock24: true, showDate: true, hideAdult: true, chNumbers: true, origOrder: true,
    parental: true, window: 'always', blocked: {}, hidden: {}, accent: 'orange'
  };
  var SET = (function () {
    var s = getJson('ativa.set', {}), k, out = {};
    for (k in DEF) { if (DEF.hasOwnProperty(k)) { out[k] = s.hasOwnProperty(k) ? s[k] : DEF[k]; } }
    if (!out.blocked || typeof out.blocked !== 'object') { out.blocked = {}; }
    if (!out.hidden || typeof out.hidden !== 'object') { out.hidden = {}; }
    return out;
  })();
  function saveSet() { setJson('ativa.set', SET); }
  function pinGet() { return store.get('ativa.pin') || '0000'; }

  // ================================================================ aparelho
  function randByte() { return Math.floor(Math.random() * 256); }
  function hex2(n) { var s = n.toString(16).toUpperCase(); return s.length < 2 ? '0' + s : s; }
  function newMac() {
    var b = [(randByte() & 0xFE) | 0x02], i, out = [];
    for (i = 1; i < 6; i++) { b.push(randByte()); }
    for (i = 0; i < 6; i++) { out.push(hex2(b[i])); }
    return out.join(':');
  }
  function newKey() { var s = '', i; for (i = 0; i < 6; i++) { s += hex2(randByte()); } return s.toLowerCase(); }
  var D = { mac: '', key: '' };
  function loadDevice(forceNew) {
    var mac = forceNew ? null : store.get('ativa.mac');
    var key = forceNew ? null : store.get('ativa.key');
    if (!mac || !/^[0-9A-F]{2}(:[0-9A-F]{2}){5}$/.test(mac)) { mac = newMac(); store.set('ativa.mac', mac); }
    if (!key || !/^[0-9a-f]{12}$/.test(key)) { key = newKey(); store.set('ativa.key', key); }
    D.mac = mac; D.key = key;
  }
  function prettyKey(k) { k = String(k || '').toUpperCase(); return k.substr(0, 4) + '-' + k.substr(4, 4) + '-' + k.substr(8, 4); }

  // ================================================================ rede
  function api(action, params, done, fail) {
    var xhr = new XMLHttpRequest();
    try { xhr.open('POST', API, true); } catch (e) { if (fail) { fail('Endereço do servidor inválido'); } return; }
    xhr.setRequestHeader('Content-Type', 'application/json');
    xhr.setRequestHeader('apikey', CFG.SUPABASE_ANON_KEY || '');
    xhr.setRequestHeader('Authorization', 'Bearer ' + (CFG.SUPABASE_ANON_KEY || ''));
    xhr.timeout = 45000;
    xhr.onload = function () {
      var body = null;
      try { body = JSON.parse(xhr.responseText); } catch (e) { body = null; }
      if (!body) { if (fail) { fail('O servidor respondeu algo inesperado'); } return; }
      if (xhr.status >= 200 && xhr.status < 300 && body.ok !== false) { if (done) { done(body); } return; }
      if (fail) { fail(body.error || ('O servidor respondeu ' + xhr.status), body); }
    };
    xhr.onerror = function () { if (fail) { fail('Sem conexão com a internet'); } };
    xhr.ontimeout = function () { if (fail) { fail('O servidor demorou demais para responder'); } };
    try { xhr.send(JSON.stringify({ mac: D.mac, device_key: D.key, action: action, params: params || {} })); }
    catch (e) { if (fail) { fail('Não foi possível enviar o pedido'); } }
  }

  // ================================================================ perfis
  var COLORS = ['#F97316', '#3B82F6', '#8B5CF6', '#10B981', '#EC4899'];
  function profiles() {
    var p = getJson('ativa.profiles', null);
    if (!p || !p.length) { p = [{ id: 'p1', name: 'Perfil 1', color: COLORS[0] }]; setJson('ativa.profiles', p); }
    return p;
  }
  var PROF = store.get('ativa.profile') || 'p1';
  function pk(name) { return 'ativa.' + name + '.' + PROF; }
  // Dados antigos (antes dos perfis) passam para o Perfil 1.
  (function migrate() {
    var olds = ['fav', 'watch'], i;
    for (i = 0; i < olds.length; i++) {
      var o = store.get('ativa.' + olds[i]);
      if (o && !store.get('ativa.' + olds[i] + '.p1')) { store.set('ativa.' + olds[i] + '.p1', o); }
    }
  })();

  // ================================================================ favoritos / histórico
  function favs() { return getJson(pk('fav'), []); }
  function isFav(id) { var f = favs(), i; for (i = 0; i < f.length; i++) { if (f[i].id === id) { return true; } } return false; }
  function toggleFav(item) {
    var f = favs(), i, found = -1;
    for (i = 0; i < f.length; i++) { if (f[i].id === item.id) { found = i; break; } }
    if (found >= 0) { f.splice(found, 1); toast('Removido dos favoritos'); }
    else {
      f.unshift({ id: item.id, sid: item.sid, type: item.type, title: item.title, logo: item.logo || null, num: item.num || null, nq: item.variants ? item.variants.length : 0 });
      if (f.length > 200) { f.length = 200; }
      toast('Adicionado aos favoritos');
    }
    setJson(pk('fav'), f);
    text($('fav-count'), f.length);
  }
  function watchAll() { return getJson(pk('watch'), []); }
  function watchOf(id) { var w = watchAll(), i; for (i = 0; i < w.length; i++) { if (w[i].id === id) { return w[i]; } } return null; }
  function saveWatch(item, pos, dur) {
    if (!item || item.type === 'live' || !dur || dur < 60) { return; }
    var w = watchAll(), i, found = -1;
    for (i = 0; i < w.length; i++) { if (w[i].id === item.id) { found = i; break; } }
    if (found >= 0) { w.splice(found, 1); }
    if (pos > dur * 0.95 || pos < 30) { setJson(pk('watch'), w); return; }
    w.unshift({ id: item.id, sid: item.sid, type: item.type, title: item.title, logo: item.logo || null,
      pos: Math.floor(pos), dur: Math.floor(dur), series: item.series || null, parent: item.parent || null });
    if (w.length > 40) { w.length = 40; }
    setJson(pk('watch'), w);
  }
  function recents() { return getJson(pk('recent'), []); }
  function addRecent(item) {
    if (!item || item.type !== 'live') { return; }
    var r = recents(), i;
    for (i = r.length - 1; i >= 0; i--) { if (r[i].id === item.id) { r.splice(i, 1); } }
    r.unshift({ id: item.id, sid: item.sid, type: 'live', title: item.title, logo: item.logo || null, num: item.num || null, nq: item.variants ? item.variants.length : 0 });
    if (r.length > 30) { r.length = 30; }
    setJson(pk('recent'), r);
    setJson(pk('lastlive'), r[0]);
  }

  // ================================================================ estado
  var S = {
    mode: 'none', name: '', expires: '', status: '',
    cats: { live: [], movies: [], series: [] },
    items: {}, loading: {},
    view: 'home', prevView: 'home',
    unlocked: false,       // PIN digitado nesta sessão (libera +18 e pastas bloqueadas)
    lastFocus: {}, liveCat: null, heroItem: null, heroShown: false,
    catalogReady: false, wantMain: false
  };

  var ADULT_RE = /(adult|xxx|porn|erotic|er[óo]tic|\+ ?18|18 ?\+)/i;
  function nightNow() { var h = new Date().getHours(); return h >= 22 || h < 6; }
  function parentalActive() { return SET.parental && (SET.window === 'always' || nightNow()); }
  function adultHidden() { return (SET.hideAdult || parentalActive()) && !S.unlocked; }
  function dropAdult(arr, nameOf) {
    if (!adultHidden()) { return arr; }
    var out = [], i;
    for (i = 0; i < arr.length; i++) { if (!ADULT_RE.test(nameOf(arr[i]))) { out.push(arr[i]); } }
    return out;
  }
  function catKey(tab, cat) { return tab + ':' + cat.id; }
  function isBlocked(tab, cat) { return !!SET.blocked[catKey(tab, cat)] && parentalActive() && !S.unlocked; }
  function catsOf(tab) {
    var arr = dropAdult(S.cats[tab] || [], function (c) { return c.name; }), out = [], i;
    for (i = 0; i < arr.length; i++) { if (!SET.hidden[catKey(tab, arr[i])]) { out.push(arr[i]); } }
    if (!SET.origOrder) {
      var cnt = getJson(pk('catcount'), {});
      out = out.slice().sort(function (a, b) { return (cnt[catKey(tab, b)] || 0) - (cnt[catKey(tab, a)] || 0); });
    }
    return out;
  }
  function countCat(tab, cat) {
    var cnt = getJson(pk('catcount'), {}), k = catKey(tab, cat);
    cnt[k] = (cnt[k] || 0) + 1;
    setJson(pk('catcount'), cnt);
  }

  // ================================================================ AGRUPADOR DE CANAIS
  /* Listas repetem o MESMO canal em várias qualidades:
       "Globo SP SD", "Globo SP HD", "Globo SP FHD", "Globo SP FHD ALT",
       "Globo SP H265", "Globo SP H265 ALT", "Globo SP FHD H265"...
     Aqui separamos o NOME BASE do RÓTULO DE QUALIDADE (só do FIM do nome) e
     juntamos tudo num card só. O player mostra um seletor de resolução.
     "Globo HD RJ" continua diferente de "Globo HD SP": só tiramos rótulos do fim. */
  function normTok(t) { return String(t).toUpperCase().replace(/[^A-Z0-9]/g, ''); }
  function resOf(t) {
    if (t === 'SD' || t === 'LD' || t === 'LOW' || t === '480' || t === '480P') { return 'SD'; }
    if (t === 'HD' || t === 'HQ' || t === '720' || t === '720P') { return 'HD'; }
    if (t === 'FHD' || t === 'FULLHD' || t === '1080' || t === '1080P') { return 'FHD'; }
    if (t === 'UHD' || t === '4K' || t === '8K' || t === '2160' || t === '2160P') { return '4K'; }
    return null;
  }
  function codecOf(t) {
    if (t === 'H265' || t === 'X265' || t === 'HEVC' || t === '265') { return 'H265'; }
    if (t === 'H264' || t === 'X264' || t === 'AVC' || t === '264') { return 'H264'; }
    return null;
  }
  function isAlt(t) { return t === 'ALT' || t === 'ALTERNATIVO' || t === 'ALTERNATIVE' || t === 'BKP' || t === 'BACKUP' || t === 'RESERVA' || t === 'OPCAO2' || t === 'OP2'; }
  function parseTitle(title) {
    var tokens = String(title || '').trim().split(/\s+/), res = null, codec = null, alt = false, cut = tokens.length, i;
    for (i = tokens.length - 1; i >= 0; i--) {
      var t = normTok(tokens[i]);
      if (!t) { if (cut === i + 1) { cut = i; } continue; }
      var r = resOf(t);
      if (r) { if (!res) { res = r; } cut = i; continue; }
      var c = codecOf(t);
      if (c) { if (!codec) { codec = c; } cut = i; continue; }
      if (isAlt(t)) { alt = true; cut = i; continue; }
      if (t === 'FULL' && res === 'HD') { res = 'FHD'; cut = i; continue; }
      break;
    }
    var base = tokens.slice(0, cut).join(' ').replace(/[\s|\-–—:]+$/, '').trim();
    if (!base) { return { base: String(title || '').trim(), label: '' }; }
    var label = [];
    if (res) { label.push(res); }
    if (codec) { label.push(codec); }
    if (alt) { label.push('ALT'); }
    return { base: base, label: label.join(' ') };
  }
  function qualityScore(label) {
    var L = label.toUpperCase(), s = 10;
    if (/\bFHD\b/.test(L)) { s = 50; } else if (/\bHD\b/.test(L)) { s = 40; } else if (/\b4K\b/.test(L)) { s = 30; } else if (/\bSD\b/.test(L)) { s = 20; }
    if (L.indexOf('H265') >= 0) { s -= 5; }
    if (L.indexOf('ALT') >= 0) { s -= 2; }
    return s;
  }
  function groupKey(base) {
    var from = 'áàâãäéèêëíìîïóòôõöúùûüçñ', to = 'aaaaaeeeeiiiiooooouuuucn', low = base.toLowerCase(), out = '', i;
    for (i = 0; i < low.length; i++) { var j = from.indexOf(low.charAt(i)); out += j >= 0 ? to.charAt(j) : low.charAt(i); }
    return out.replace(/[^a-z0-9]/g, '');
  }
  function mergeVariants(items) {
    var order = [], groups = {}, i;
    for (i = 0; i < items.length; i++) {
      var it = items[i], p = parseTitle(it.title), key = groupKey(p.base) || ('#' + it.id);
      it._label = p.label;
      it._base = p.base;
      if (!groups[key]) { groups[key] = []; order.push(key); }
      groups[key].push(it);
    }
    var out = [];
    for (i = 0; i < order.length; i++) {
      var g = groups[order[i]];
      if (g.length === 1) { out.push(g[0]); continue; }
      var used = {}, vars = [], j;
      for (j = 0; j < g.length; j++) {
        var label = g[j]._label || 'Padrão', uniq = label, n = 2;
        while (used[uniq]) { uniq = label + ' ' + n; n++; }
        used[uniq] = true;
        vars.push({ label: uniq, url: g[j].url || null, sid: g[j].sid, score: qualityScore(label) });
      }
      vars.sort(function (a, b) { return b.score - a.score; });
      var first = g[0], logo = first.logo;
      for (j = 0; j < g.length && !logo; j++) { logo = g[j].logo; }
      out.push({ id: first.id, sid: first.sid, type: first.type, title: first._base, logo: logo, num: first.num,
                 url: vars[0].url, variants: vars });
    }
    return out;
  }
  /** Qual resolução abrir: a escolhida antes neste canal > preferência > a melhor. */
  function pickVariantIdx(item) {
    var v = item.variants || [], i;
    if (!v.length) { return -1; }
    var mine = getJson('ativa.vq', {})[item.id];
    if (mine) { for (i = 0; i < v.length; i++) { if (v[i].label === mine) { return i; } } }
    var pref = SET.quality;
    if (pref !== 'best') {
      for (i = 0; i < v.length; i++) {
        var L = v[i].label.toUpperCase(), h = L.indexOf('H265') >= 0;
        if ((pref === 'uhd' && L.indexOf('4K') >= 0) || (pref === 'fhd265' && L.indexOf('FHD') >= 0 && h) ||
            (pref === 'fhd' && L.indexOf('FHD') >= 0 && !h) || (pref === 'hd' && /\bHD\b/.test(L) && !h) ||
            (pref === 'sd' && L.indexOf('SD') >= 0)) { return i; }
      }
    }
    return 0;
  }

  /** Busca (uma vez) os itens de uma pasta. Lista M3U já vem com tudo. */
  function loadItems(tab, cat, done, fail) {
    var key = tab + ':' + cat.id;
    if (S.items[key]) { done(S.items[key]); return; }
    function finish(arr) {
      var i;
      for (i = 0; i < arr.length; i++) { if (arr[i].type === 'live' && !arr[i].num) { arr[i].num = i + 1; } }
      arr = dropAdult(arr, function (it) { return it.title; });
      if (tab === 'live') { arr = mergeVariants(arr); }
      S.items[key] = arr;
      return arr;
    }
    if (S.mode === 'm3u') { done(finish((cat.items || []).slice())); return; }
    if (S.loading[key]) { S.loading[key].push(done); return; }
    S.loading[key] = [done];
    var type = tab === 'movies' ? 'movie' : tab === 'series' ? 'series' : 'live';
    api('streams', { type: type, category_id: cat.id }, function (r) {
      var arr = finish(r.items || []), cbs = S.loading[key] || [], i;
      delete S.loading[key];
      for (i = 0; i < cbs.length; i++) { cbs[i](arr); }
    }, function (msg) { delete S.loading[key]; if (fail) { fail(msg); } });
  }
  /** Acha um canal já carregado (com as qualidades) pelo id. */
  function findLoaded(id) {
    var k, i;
    for (k in S.items) {
      if (!S.items.hasOwnProperty(k)) { continue; }
      var arr = S.items[k];
      for (i = 0; i < arr.length; i++) { if (arr[i].id === id) { return arr[i]; } }
    }
    return null;
  }

  // ================================================================ FOCO / CONTROLE
  var focused = null;
  function visible(el) {
    if (!el || el.offsetParent === null) { return false; }
    var r = el.getBoundingClientRect();
    return r.width > 0 && r.height > 0;
  }
  function inView(el) {
    var r = el.getBoundingClientRect();
    return r.bottom > 0 && r.top < window.innerHeight && r.right > 0 && r.left < window.innerWidth && r.width > 0;
  }
  function activeRoot() {
    if (has($('pin'), 'on')) { return $('pin'); }
    if (has($('kbd'), 'on')) { return $('kbd'); }
    if (has($('player'), 'full')) { return has($('pl-menu'), 'on') ? $('pl-menu') : $('player'); }
    if (has($('detail'), 'on')) { return $('detail'); }
    var scr = qsa('.screen'), i;
    for (i = 0; i < scr.length; i++) { if (has(scr[i], 'on')) { return scr[i]; } }
    return document.body;
  }
  function ensureVisible(el) {
    var node = el.parentNode, padX = 60, padY = 90;
    while (node && node.nodeType === 1 && node !== document.body) {
      var canY = node.scrollHeight > node.clientHeight + 2, canX = node.scrollWidth > node.clientWidth + 2;
      if (canY || canX) {
        var r = el.getBoundingClientRect(), b = node.getBoundingClientRect();
        if (canX) {
          if (r.left < b.left + padX) { node.scrollLeft -= (b.left + padX - r.left); }
          else if (r.right > b.right - padX) { node.scrollLeft += (r.right - (b.right - padX)); }
        }
        if (canY) {
          if (has(node, 'content') && (el._row || el._blk)) {
            // O destaque desce pela tela; as pastas só sobem quando a pasta em
            // foco (título + capas) não cabe mais embaixo. Subindo, o mesmo ao contrário.
            var blk = (el._row ? el._row.parentNode : el._blk).getBoundingClientRect();
            if (blk.bottom > b.bottom - 16) { node.scrollTop += (blk.bottom - (b.bottom - 16)); }
            else if (blk.top < b.top + 8) { node.scrollTop -= (b.top + 8 - blk.top); }
          } else if (r.top < b.top + padY) { node.scrollTop -= (b.top + padY - r.top); }
          else if (r.bottom > b.bottom - padY) { node.scrollTop += (r.bottom - (b.bottom - padY)); }
        }
      }
      node = node.parentNode;
    }
  }
  function setFocus(el) {
    if (!el) { return; }
    if (focused && focused !== el) { off(focused, 'on'); }
    focused = el;
    on(el, 'on');
    ensureVisible(el);
    if (el._onFocus) { el._onFocus(); }
  }
  function freeCandidates() {
    var root = activeRoot(), all = list(qsa('.f', root)), out = [], i;
    for (i = 0; i < all.length; i++) {
      var el = all[i];
      if (el._row || el._list) {
        if (!inView(el)) { continue; }
        var box = (el._row || el._list).getBoundingClientRect(), r = el.getBoundingClientRect();
        if (r.left < box.left - 2 || r.right > box.right + 2 || r.top < box.top - 30 || r.bottom > box.bottom + 30) { continue; }
      }
      if (visible(el)) { out.push(el); }
    }
    return out;
  }
  function railTarget() { return qs('#rail .rail-item.sel') || qs('#rail .rail-logo'); }
  function focusFirst(preferred) {
    if (preferred && preferred.parentNode && visible(preferred)) { setFocus(preferred); return; }
    var f = freeCandidates();
    if (f.length) { setFocus(f[0]); } else { if (focused) { off(focused, 'on'); } focused = null; }
  }
  function center(r) { return { x: r.left + r.width / 2, y: r.top + r.height / 2 }; }
  function nearest(cur, items, dir) {
    var i, best = null, bestScore = Infinity, cr = cur.getBoundingClientRect(), cc = center(cr);
    for (i = 0; i < items.length; i++) {
      var el = items[i];
      if (el === cur) { continue; }
      var r = el.getBoundingClientRect(), c = center(r), dx = c.x - cc.x, dy = c.y - cc.y, along, across, overlap;
      if (dir === 'left' || dir === 'right') {
        if (dir === 'right' && r.left < cr.right - 4) { continue; }
        if (dir === 'left' && r.right > cr.left + 4) { continue; }
        along = dir === 'right' ? dx : -dx; across = Math.abs(dy);
        overlap = Math.min(r.bottom, cr.bottom) - Math.max(r.top, cr.top);
      } else {
        if (dir === 'down' && r.top < cr.bottom - 4) { continue; }
        if (dir === 'up' && r.bottom > cr.top + 4) { continue; }
        along = dir === 'down' ? dy : -dy; across = Math.abs(dx);
        overlap = Math.min(r.right, cr.right) - Math.max(r.left, cr.left);
      }
      if (along <= 0) { continue; }
      var score = along + across * (overlap > 0 ? 0.5 : 3);
      if (score < bestScore) { bestScore = score; best = el; }
    }
    return best;
  }
  function nextF(el, step) {
    var n = step > 0 ? el.nextElementSibling : el.previousElementSibling;
    while (n && !has(n, 'f')) { n = step > 0 ? n.nextElementSibling : n.previousElementSibling; }
    return n;
  }
  /** Capa por onde entrar numa fileira: a mais alinhada com a posição atual. */
  function rowEntry(blk, cx) {
    var row = qs('.row', blk), cards = row ? list(row.children) : [], best = null, bd = Infinity, i;
    for (i = 0; i < cards.length; i++) {
      if (!has(cards[i], 'f')) { continue; }
      var r = cards[i].getBoundingClientRect();
      if (r.right < 0 || r.left > window.innerWidth) { continue; }
      var d = Math.abs(center(r).x - cx);
      if (d < bd) { bd = d; best = cards[i]; }
    }
    if (!best && cards.length && has(cards[0], 'f')) { best = cards[0]; }
    return best;
  }
  /** Ordem vertical das fileiras, sem pular nada:
      [Ver Todos] -> capas -> [Ver Todos da próxima pasta] -> capas -> ...
      `part` diz onde o foco está agora: 'see' (botão) ou 'cards' (capas). */
  function vertNext(blk, part, dir, cx) {
    var b, s, c;
    if (dir === 'down') {
      if (part === 'see') { c = rowEntry(blk, cx); if (c) { return c; } }
      for (b = blk.nextElementSibling; b; b = b.nextElementSibling) {
        s = qs('.see', b); if (s) { return s; }
        c = rowEntry(b, cx); if (c) { return c; }
      }
      return null;
    }
    if (part === 'cards') { s = qs('.see', blk); if (s) { return s; } }
    for (b = blk.previousElementSibling; b; b = b.previousElementSibling) {
      c = rowEntry(b, cx); if (c) { return c; }
      s = qs('.see', b); if (s) { return s; }
    }
    return null;
  }
  function move(dir) {
    var cur = focused;
    if (!cur || !cur.parentNode || !visible(cur) || !activeRoot().contains(cur)) { focusFirst(); return; }
    var t = null;
    if (cur._row) {
      if (dir === 'left' || dir === 'right') {
        t = nextF(cur, dir === 'right' ? 1 : -1);
        if (t) { setFocus(t); maybeMore(cur._row, t); return; }
        if (dir === 'right') { return; }
        setFocus(railTarget()); return;
      }
      S.navX = center(cur.getBoundingClientRect()).x;      // coluna de onde saiu
      t = vertNext(cur._row.parentNode, 'cards', dir, S.navX);
      if (t) { setFocus(t); return; }
      if (dir === 'down') { return; }
      if (S.heroShown) { $('content').scrollTop = 0; setFocus($('hero-play')); return; }
    }
    if (cur._blk) {                                         // botão "Ver Todos"
      if (dir === 'left') { setFocus(railTarget()); return; }
      if (dir === 'right') { return; }
      t = vertNext(cur._blk, 'see', dir, S.navX || center(cur.getBoundingClientRect()).x);
      if (t) { setFocus(t); return; }
      if (dir === 'down') { return; }
      if (S.heroShown) { $('content').scrollTop = 0; setFocus($('hero-play')); return; }
    }
    // Do destaque (lá em cima) para baixo: entra na primeira pasta pelo "Ver Todos".
    if (dir === 'down' && $('hero').contains(cur)) {
      var first = qs('#rows .row-block');
      if (first) {
        S.navX = center(cur.getBoundingClientRect()).x;
        t = qs('.see', first) || rowEntry(first, S.navX);
        if (t) { setFocus(t); return; }
      }
    }
    if (cur._list) {
      var cols = cur._list._cols ? cur._list._cols() : 1;
      if (dir === 'up' || dir === 'down') {
        var step = dir === 'down' ? cols : -cols, n = cur, k;
        for (k = 0; k < Math.abs(step) && n; k++) { n = nextF(n, step > 0 ? 1 : -1); }
        if (n) { setFocus(n); maybeMoreList(cur._list, n); return; }
        if (dir === 'down') { return; }
      } else if (cols > 1) {
        var idx = cur._idx || 0;
        if (dir === 'right' && (idx % cols) < cols - 1) { t = nextF(cur, 1); if (t) { setFocus(t); maybeMoreList(cur._list, t); return; } }
        if (dir === 'left' && (idx % cols) > 0) { t = nextF(cur, -1); if (t) { setFocus(t); return; } }
      }
      if (cur._list._exit && cur._list._exit[dir]) { t = cur._list._exit[dir](); if (t) { setFocus(t); return; } }
      if (dir === 'left' && has($('main'), 'on') && activeRoot() === $('main')) { setFocus(railTarget()); return; }
    }
    t = nearest(cur, freeCandidates(), dir);
    if (t) { setFocus(t); }
  }

  // ================================================================ CARDS
  function img(src, cls) {
    var i = document.createElement('img');
    if (cls) { i.className = cls; }
    i.alt = '';
    try { i.loading = 'lazy'; i.decoding = 'async'; } catch (e) {}
    i.src = src;
    return i;
  }
  function initials(t) {
    var w = String(t || '').replace(/[^0-9A-Za-zÀ-ú ]/g, ' ').trim().split(/\s+/);
    return ((w[0] || '?').charAt(0) + (w[1] || '').charAt(0)).toUpperCase();
  }
  function nq(item) { return item.variants ? item.variants.length : (item.nq || 0); }
  function card(item, shape, onOk) {
    var b = mk('button', 'f card ' + shape);
    if (shape === 'wide') {
      var media = mk('div', 'media');
      if (item.logo) {
        var im = img(item.logo);
        im.onerror = function () { if (im.parentNode) { im.parentNode.replaceChild(mk('div', 'ph', initials(item.title)), im); } };
        media.appendChild(im);
      } else { media.appendChild(mk('div', 'ph', initials(item.title))); }
      media.appendChild(mk('span', 'ch', (SET.chNumbers && item.num ? 'CH ' + item.num + ' • ' : '') + item.title));
      if (item.type === 'live') { media.appendChild(mk('span', 'lv', '● AO VIVO')); }
      if (nq(item) > 1) { media.appendChild(mk('span', 'qn', nq(item) + ' QUALIDADES')); }
      b.appendChild(media);
      var tx = mk('div', 'txt');
      tx.appendChild(mk('div', 't1', item.title));
      tx.appendChild(mk('div', 't2', item.type === 'live' ? 'Canal ao vivo' : item.type === 'series' ? 'Série' : item.type === 'episode' ? (item.series || 'Episódio') : 'Filme'));
      var w = watchOf(item.id);
      if (w && w.dur > 0) {
        var bar = mk('div', 'bar'), fl = mk('i');
        fl.style.width = Math.min(100, Math.round(w.pos / w.dur * 100)) + '%';
        bar.appendChild(fl); tx.appendChild(bar);
      }
      b.appendChild(tx);
    } else {
      if (item.logo) {
        var ip = img(item.logo);
        ip.onerror = function () { if (ip.parentNode) { ip.parentNode.replaceChild(mk('div', 'ph', item.title), ip); } };
        b.appendChild(ip);
      } else { b.appendChild(mk('div', 'ph', item.title)); }
      b.appendChild(mk('span', 'q', item.type === 'series' ? 'SÉRIE' : 'HD'));
      if (item.rating && parseFloat(item.rating) > 0) { b.appendChild(mk('span', 'rt', '★ ' + parseFloat(item.rating).toFixed(1))); }
      var pt = mk('div', 'txt');
      pt.appendChild(mk('div', 't1', item.title));
      b.appendChild(pt);
      var w2 = watchOf(item.id);
      if (w2 && w2.dur > 0) {
        var bar2 = mk('div', 'bar'), f2 = mk('i');
        f2.style.width = Math.min(100, Math.round(w2.pos / w2.dur * 100)) + '%';
        bar2.appendChild(f2); b.appendChild(bar2);
      }
    }
    if (isFav(item.id)) { b.appendChild(mk('span', 'star', '★')); }
    b.onclick = function () { onOk(item); };
    b._fav = function () { toggleFav(item); };
    b._item = item;
    b._onFocus = function () { heroSoon(item); };
    return b;
  }

  // ================================================================ DESTAQUE
  var heroTimer = 0;
  function heroSoon(item) {
    if (!S.heroShown) { return; }
    if (heroTimer) { clearTimeout(heroTimer); }
    heroTimer = setTimeout(function () { setHero(item); }, 260);
  }
  function setHero(item) {
    if (!item) { return; }
    S.heroItem = item;
    var bg = $('hero-bg'), live = item.type === 'live';
    bg.className = 'hero-bg' + (live ? ' logo' : '');
    bg.style.backgroundImage = item.logo ? 'url("' + String(item.logo).replace(/"/g, '%22') + '")' : 'none';
    var badge = $('hero-badge');
    text(badge, live ? '● AO VIVO AGORA' : item.type === 'series' ? 'SÉRIE EM DESTAQUE' : 'EM DESTAQUE');
    badge.className = 'badge ' + (live ? 'live' : 'brand');
    text($('hero-chip'), live ? (SET.chNumbers && item.num ? 'CH ' + item.num + ' • ' : '') + item.title : (item.type === 'series' ? 'SÉRIE' : 'FILME'));
    text($('hero-title'), item.title);
    var meta = $('hero-meta');
    clear(meta);
    if (item.rating && parseFloat(item.rating) > 0) { meta.appendChild(document.createTextNode('★ ' + parseFloat(item.rating).toFixed(1))); }
    else if (live) { meta.appendChild(document.createTextNode('Ao vivo')); }
    if (nq(item) > 1) { meta.appendChild(mk('span', null, nq(item) + ' qualidades: escolha no player')); }
    var w = watchOf(item.id);
    if (w && w.dur) { meta.appendChild(mk('span', null, 'Parou em ' + clock(w.pos))); }
    text($('hero-plot'), item.plot || (live ? 'Aperte OK para assistir agora.' : ''));
    text(qs('#hero-play span'), live ? 'Assistir ao vivo' : (w && w.pos > 30 ? 'Continuar' : 'Assistir Agora'));
    text(qs('#hero-fav span'), isFav(item.id) ? 'Remover dos favoritos' : 'Favoritar');
  }

  // ================================================================ FILEIRAS
  var rowObserver = null;
  function rowBlock(src) {
    var blk = mk('div', 'row-block'), head = mk('div', 'row-head');
    head.appendChild(mk('h2', null, src.title));
    if (src.tag) { head.appendChild(mk('span', 'tag', src.tag)); }
    if (src.onSeeAll) {
      var see = mk('button', 'f see');
      see.innerHTML = ico('grid') + '<span>Ver Todos</span>';
      see.onclick = src.onSeeAll;
      see._blk = blk;
      head.appendChild(see);
    }
    var cnt = mk('span', 'count');
    head.appendChild(cnt);
    blk.appendChild(head);
    var row = mk('div', 'row');
    blk.appendChild(row);
    row._src = src; row._shown = 0; row._cnt = cnt;
    if (src.items) { fillRow(row, src.items); }
    else {
      row.appendChild(mk('div', 'row-msg', 'Carregando…'));
      if (rowObserver) { rowObserver.observe(blk); } else { loadRow(row); }
    }
    blk._row = row;
    return blk;
  }
  function loadRow(row) {
    if (row._started) { return; }
    row._started = true;
    row._src.load(function (items) { clear(row); fillRow(row, items); }, function (msg) { clear(row); row.appendChild(mk('div', 'row-msg', msg)); });
  }
  function fillRow(row, items) {
    row._items = items; row._shown = 0;
    text(row._cnt, items.length ? items.length + (items.length === 1 ? ' item' : ' itens') : '');
    if (!items.length) { row.appendChild(mk('div', 'row-msg', 'Nada por aqui ainda.')); return; }
    appendRow(row);
    if (!S.heroItem && S.heroShown) { setHero(items[0]); }
  }
  function appendRow(row) {
    var items = row._items || [], end = Math.min(items.length, row._shown + PAGE), i, frag = document.createDocumentFragment();
    for (i = row._shown; i < end; i++) {
      var c = card(items[i], row._src.shape, row._src.onOk || function (x) { openItem(x, items); });
      c._row = row; c._pl = items;
      frag.appendChild(c);
    }
    row.appendChild(frag);
    row._shown = end;
  }
  function maybeMore(row, el) {
    var left = 0, n = el;
    while (n && left < 6) { n = n.nextElementSibling; left++; }
    if (left < 6 && row._items && row._shown < row._items.length) { appendRow(row); }
  }
  function setupObserver() {
    if (!('IntersectionObserver' in window)) { return; }
    rowObserver = new IntersectionObserver(function (entries) {
      var i;
      for (i = 0; i < entries.length; i++) {
        if (entries[i].isIntersecting && entries[i].target._row) { rowObserver.unobserve(entries[i].target); loadRow(entries[i].target._row); }
      }
    }, { root: $('content'), rootMargin: '700px 0px' });
  }

  // ================================================================ LISTAS LONGAS
  function longList(box, items, make, opts) {
    clear(box);
    box._items = items; box._shown = 0; box._make = make;
    box._cols = opts && opts.cols ? opts.cols : function () { return 1; };
    box._exit = opts && opts.exit ? opts.exit : null;
    appendList(box);
  }
  function appendList(box) {
    var items = box._items || [], end = Math.min(items.length, box._shown + LIST_PAGE), i, frag = document.createDocumentFragment();
    for (i = box._shown; i < end; i++) {
      var el = box._make(items[i], i);
      el._list = box; el._idx = i;
      frag.appendChild(el);
    }
    box.appendChild(frag);
    box._shown = end;
  }
  function maybeMoreList(box, el) { if (box._items && box._shown < box._items.length && (el._idx || 0) > box._shown - 12) { appendList(box); } }
  function gridCols(box) {
    return function () {
      var kids = box.children, i, top = null, n = 0;
      for (i = 0; i < kids.length; i++) { var t = kids[i].offsetTop; if (top === null) { top = t; } if (t !== top) { break; } n++; }
      return Math.max(1, n);
    };
  }

  // ================================================================ TECLADO NA TELA / PIN
  var KB = null;
  function openKeyboard(title, initial, done) {
    KB = { value: initial || '', done: done, prev: focused };
    text($('kbd-title'), title);
    var box = $('kbd-keys');
    clear(box);
    var rows = ['1234567890', 'QWERTYUIOP', 'ASDFGHJKLÇ', 'ZXCVBNM-.\''], i, j;
    for (i = 0; i < rows.length; i++) {
      for (j = 0; j < rows[i].length; j++) {
        (function (ch) { var b = mk('button', 'f key', ch); b.onclick = function () { kbType(ch); }; box.appendChild(b); })(rows[i].charAt(j));
      }
    }
    var sp = mk('button', 'f key wide', 'Espaço'); sp.onclick = function () { kbType(' '); }; box.appendChild(sp);
    var del = mk('button', 'f key wide', 'Apagar'); del.onclick = function () { KB.value = KB.value.slice(0, -1); kbShow(); }; box.appendChild(del);
    var okb = mk('button', 'f key wide ok', 'Confirmar'); okb.onclick = function () { closeKeyboard(true); }; box.appendChild(okb);
    kbShow();
    on($('kbd'), 'on');
    setFocus(box.children[10]);
  }
  function kbType(ch) { if (KB.value.length < 40) { KB.value += KB.value.length && /[A-Z]/.test(ch) && /\S$/.test(KB.value) ? ch.toLowerCase() : ch; kbShow(); } }
  function kbShow() { text($('kbd-value'), KB.value); }
  function closeKeyboard(ok) {
    off($('kbd'), 'on');
    var k = KB; KB = null;
    if (k && k.prev) { focusFirst(k.prev); }
    if (ok && k && k.done) { k.done(k.value.trim()); }
  }

  var PIN = null;
  function askPin(title, sub, check, done) {
    PIN = { value: '', check: check, done: done, prev: focused };
    text($('pin-title'), title); text($('pin-sub'), sub || ''); text($('pin-err'), '');
    var box = $('pin-keys'), keys = ['1', '2', '3', '4', '5', '6', '7', '8', '9', '⌫', '0', 'OK'], i;
    clear(box);
    for (i = 0; i < keys.length; i++) {
      (function (k) {
        var b = mk('button', 'f key' + (k === 'OK' ? ' ok' : ''), k);
        b.onclick = function () {
          if (k === '⌫') { PIN.value = PIN.value.slice(0, -1); }
          else if (k === 'OK') { pinSubmit(); return; }
          else if (PIN.value.length < 4) { PIN.value += k; if (PIN.value.length === 4) { pinDots(); setTimeout(pinSubmit, 120); return; } }
          pinDots();
        };
        box.appendChild(b);
      })(keys[i]);
    }
    pinDots();
    on($('pin'), 'on');
    setFocus(box.children[0]);
  }
  function pinDots() { var d = list($('pin-dots').children), i; for (i = 0; i < d.length; i++) { if (i < PIN.value.length) { on(d[i], 'full'); } else { off(d[i], 'full'); } } }
  function pinSubmit() {
    if (!PIN) { return; }
    if (PIN.value.length !== 4) { text($('pin-err'), 'O PIN tem 4 números.'); return; }
    if (PIN.check && !PIN.check(PIN.value)) { text($('pin-err'), 'PIN incorreto.'); PIN.value = ''; pinDots(); return; }
    var p = PIN; PIN = null;
    off($('pin'), 'on');
    if (p.prev) { focusFirst(p.prev); }
    p.done(p.value);
  }
  function closePin() { var p = PIN; PIN = null; off($('pin'), 'on'); if (p && p.prev) { focusFirst(p.prev); } }
  /** Pede o PIN só quando precisa (controle parental ativo e ainda não liberado nesta sessão). */
  function withPin(why, go) {
    if (S.unlocked) { go(); return; }
    askPin('Digite o PIN', why, function (v) { return v === pinGet(); }, function () { S.unlocked = true; go(); });
  }

  // ================================================================ TELAS
  function showScreen(id) {
    var scr = qsa('.screen'), i;
    for (i = 0; i < scr.length; i++) { off(scr[i], 'on'); }
    on($(id), 'on');
  }
  function markRail(name) {
    var items = list(qsa('#rail [data-view]')), i;
    for (i = 0; i < items.length; i++) { if (items[i].getAttribute('data-view') === name) { on(items[i], 'sel'); } else { off(items[i], 'sel'); } }
    var ph = $('pill-home'), pf = qs('.top .pill[data-view="favorites"]');
    if (name === 'home') { on(ph, 'sel'); } else { off(ph, 'sel'); }
    if (name === 'favorites') { on(pf, 'sel'); } else { off(pf, 'sel'); }
  }
  function hideAllViews() {
    $('hero').style.display = 'none';
    $('rows').style.display = 'none';
    off($('grid-view'), 'on'); off($('live-view'), 'on');
    S.heroShown = false;
  }
  function setView(name, arg) {
    if (name === 'settings') { openSettings(); return; }
    if (focused && S.view) { S.lastFocus[S.view] = focused; }
    if (name !== 'live') { stopMini(); }
    if (name !== 'grid' && name !== 'search') { S.prevView = name; }
    S.view = name;
    hideAllViews();
    $('content').scrollTop = 0;
    markRail(name === 'grid' || name === 'search' ? S.prevView : name);
    if (name === 'home' || name === 'movies' || name === 'series') {
      $('hero').style.display = '';
      $('rows').style.display = '';
      S.heroShown = true; S.heroItem = null;
      buildRows(name);
      focusFirst(qs('#hero-play'));
      return;
    }
    if (name === 'live') { on($('live-view'), 'on'); renderLive(); return; }
    on($('grid-view'), 'on');
    renderGrid(name, arg);
  }

  // ---------- Início / Filmes / Séries ----------
  function buildRows(view) {
    var root = $('rows'), i, srcs = [], w = watchAll(), f = favs(), rc = recents();
    clear(root);
    if (view === 'home') {
      if (rc.length) { srcs.push({ title: 'Canais Recentes', items: rc, shape: 'wide' }); }
      if (w.length) { srcs.push({ title: 'Continuar Assistindo', items: w, shape: 'wide', onSeeAll: function () { setView('continue'); } }); }
      if (f.length) { srcs.push({ title: 'Seus Favoritos', items: f, shape: 'poster', onSeeAll: function () { setView('favorites'); } }); }
      pushCats(srcs, 'live', 4, 'AO VIVO');
      pushCats(srcs, 'movies', 2, 'FILMES');
      pushCats(srcs, 'series', 2, 'SÉRIES');
    } else { pushCats(srcs, view, 9999, view === 'movies' ? 'FILMES' : 'SÉRIES'); }
    if (!srcs.length) { root.appendChild(mk('p', 'empty', 'Nenhuma pasta nesta lista. Confira a lista cadastrada no painel.')); return; }
    var frag = document.createDocumentFragment();
    for (i = 0; i < srcs.length; i++) { frag.appendChild(rowBlock(srcs[i])); }
    root.appendChild(frag);
    if (rc.length) { setHero(rc[0]); } else if (w.length) { setHero(w[0]); } else if (f.length) { setHero(f[0]); }
  }
  function pushCats(srcs, tab, max, tag) {
    var cats = catsOf(tab), i, n = 0;
    for (i = 0; i < cats.length && n < max; i++) {
      if (isBlocked(tab, cats[i])) { continue; }     // pastas com PIN não aparecem nas fileiras
      n++;
      (function (cat) {
        srcs.push({
          title: cat.name, tag: tag, shape: tab === 'live' ? 'wide' : 'poster',
          load: function (done, fail) { loadItems(tab, cat, done, fail); },
          onSeeAll: function () {
            countCat(tab, cat);
            if (tab === 'live') { S.liveCat = cat; setView('live'); } else { setView('grid', { tab: tab, cat: cat }); }
          }
        });
      })(cats[i]);
    }
  }

  // ---------- Grade (favoritos, continuar, busca, ver todos) ----------
  function renderGrid(name, arg) {
    var grid = $('grid'), items = [], title = '', shape = 'poster';
    off($('search-line'), 'on');
    text($('grid-msg'), '');
    if (name === 'favorites') { items = favs(); title = 'Seus Favoritos'; }
    else if (name === 'continue') { items = watchAll(); title = 'Continuar Assistindo'; shape = 'wide'; }
    else if (name === 'search') {
      on($('search-line'), 'on');
      clear(grid);
      text($('grid-title'), 'Buscar'); text($('grid-count'), '');
      text($('grid-msg'), 'Aperte OK no campo para escrever.');
      focusFirst($('search-input'));
      return;
    } else if (name === 'grid' && arg) {
      title = arg.cat.name; shape = arg.tab === 'live' ? 'wide' : 'poster';
      text($('grid-title'), title); text($('grid-count'), 'Carregando…');
      clear(grid);
      loadItems(arg.tab, arg.cat, function (its) { showGrid(its, shape); }, function (msg) { text($('grid-msg'), msg); text($('grid-count'), ''); });
      return;
    }
    text($('grid-title'), title);
    showGrid(items, shape);
  }
  function showGrid(items, shape) {
    var grid = $('grid');
    text($('grid-count'), items.length + (items.length === 1 ? ' item' : ' itens'));
    longList(grid, items, function (it) { var c = card(it, shape, function (x) { openItem(x, items); }); c._onFocus = null; return c; }, { cols: gridCols(grid) });
    text($('grid-msg'), items.length ? '' : 'Nada por aqui ainda. Segure OK numa capa para favoritar.');
    focusFirst(qs('#grid .f'));
  }
  function doSearch(q) {
    q = (q || '').trim();
    text($('search-input'), q || 'Toque OK para escrever');
    if (q.length < 2) { text($('grid-msg'), 'Escreva pelo menos 2 letras.'); return; }
    clear($('grid'));
    text($('grid-msg'), 'Procurando “' + q + '”…');
    if (S.mode === 'm3u') {
      var found = [], lower = q.toLowerCase(), tabs = ['live', 'movies', 'series'], t, i, j;
      for (t = 0; t < tabs.length; t++) {
        var cats = S.cats[tabs[t]] || [];
        for (i = 0; i < cats.length; i++) {
          var its = cats[i].items || [];
          for (j = 0; j < its.length && found.length < 300; j++) { if (its[j].title.toLowerCase().indexOf(lower) >= 0) { found.push(its[j]); } }
        }
      }
      showSearch(found, q); return;
    }
    api('search', { q: q }, function (r) { showSearch(r.items || [], q); }, function (msg) { text($('grid-msg'), msg); });
  }
  function showSearch(items, q) {
    items = dropAdult(items, function (it) { return it.title; });
    var lives = [], rest = [], i;
    for (i = 0; i < items.length; i++) { if (items[i].type === 'live') { lives.push(items[i]); } else { rest.push(items[i]); } }
    items = mergeVariants(lives).concat(rest);
    showGrid(items, 'poster');
    if (!items.length) { text($('grid-msg'), 'Nada encontrado para “' + q + '”.'); focusFirst($('search-input')); }
  }

  // ---------- TV ao vivo ----------
  function renderLive() {
    var cats = catsOf('live'), box = $('live-cats');
    if (!cats.length) { clear(box); clear($('live-list')); text($('live-msg'), 'Nenhuma pasta de canais nesta lista.'); focusFirst(); return; }
    if (!S.liveCat || isBlocked('live', S.liveCat)) {
      S.liveCat = null;
      var i0;
      for (i0 = 0; i0 < cats.length && !S.liveCat; i0++) { if (!isBlocked('live', cats[i0])) { S.liveCat = cats[i0]; } }
      if (!S.liveCat) { S.liveCat = cats[0]; }
    }
    longList(box, cats, function (c) {
      var b = mk('button', 'f lcat');
      b.appendChild(mk('span', null, (isBlocked('live', c) ? '🔒 ' : '') + c.name));
      if (S.items['live:' + c.id]) { b.appendChild(mk('em', null, String(S.items['live:' + c.id].length))); }
      if (S.liveCat && c.id === S.liveCat.id) { on(b, 'sel'); }
      b.onclick = function () {
        if (isBlocked('live', c)) { withPin('Esta pasta está bloqueada.', function () { renderLive(); pickLiveCat(c, true); }); return; }
        countCat('live', c); pickLiveCat(c, true);
      };
      b._cat = c;
      return b;
    }, { exit: { right: function () { return qs('#live-list .chan.playing') || qs('#live-list .f'); } } });
    var idx = 0, i;
    for (i = 0; i < cats.length; i++) { if (cats[i].id === S.liveCat.id) { idx = i; } }
    while (box._shown <= idx && box._shown < cats.length) { appendList(box); }
    if (isBlocked('live', S.liveCat)) { clear($('live-list')); text($('live-msg'), 'Pasta bloqueada: aperte OK nela e digite o PIN.'); }
    else { pickLiveCat(S.liveCat, false); }
    focusFirst(box.children[idx]);
  }
  function pickLiveCat(cat, focusList) {
    S.liveCat = cat;
    var btns = list($('live-cats').children), i;
    for (i = 0; i < btns.length; i++) { if (btns[i]._cat && btns[i]._cat.id === cat.id) { on(btns[i], 'sel'); } else { off(btns[i], 'sel'); } }
    text($('live-title'), cat.name); text($('live-count'), 'Carregando…'); text($('live-msg'), '');
    clear($('live-list'));
    loadItems('live', cat, function (items) {
      if (S.liveCat !== cat) { return; }
      text($('live-count'), items.length + (items.length === 1 ? ' canal' : ' canais'));
      var lst = $('live-list');
      longList(lst, items, function (it) { return chanRow(it, items); }, {
        cols: function () { return 1; },
        exit: { left: function () { return qs('#live-cats .lcat.sel') || qs('#live-cats .f'); } }
      });
      text($('live-msg'), items.length ? '' : 'Esta pasta está vazia.');
      if (focusList) { focusFirst(qs('#live-list .f')); }
    }, function (msg) { if (S.liveCat === cat) { text($('live-count'), ''); text($('live-msg'), msg); } });
  }
  function chanRow(it, items) {
    var b = mk('button', 'f chan'), lg = mk('div', 'lg');
    if (it.logo) {
      var im = img(it.logo);
      im.onerror = function () { if (im.parentNode) { im.parentNode.replaceChild(document.createTextNode(initials(it.title)), im); } };
      lg.appendChild(im);
    } else { text(lg, initials(it.title)); }
    b.appendChild(lg);
    var ci = mk('div', 'ci'), cl = mk('div', 'cl');
    if (SET.chNumbers && it.num) { cl.appendChild(mk('span', 'num', 'CH ' + it.num)); }
    cl.appendChild(mk('span', 'nm', it.title));
    if (nq(it) > 1) { cl.appendChild(mk('span', 'qn', nq(it) + 'Q')); }
    cl.appendChild(mk('span', 'lv', '● AO VIVO'));
    ci.appendChild(cl);
    var subTxt = nq(it) > 1 ? it.variants.map(function (v) { return v.label; }).slice(0, 5).join(' · ') : 'Aperte OK para ver aqui ao lado';
    ci.appendChild(mk('div', 'sub', (isFav(it.id) ? '★ ' : '') + subTxt));
    b.appendChild(ci);
    if (P.item && P.item.id === it.id) { on(b, 'playing'); }
    b.onclick = function () {
      if (P.item && P.item.id === it.id && has($('player'), 'mini')) { goFull(); return; }
      var pls = list(qsa('#live-list .chan.playing')), i;
      for (i = 0; i < pls.length; i++) { off(pls[i], 'playing'); }
      on(b, 'playing');
      playItem(it, 0, items, 'mini');
      loadEpg(it);
    };
    b._fav = function () { toggleFav(it); };
    b._item = it;
    return b;
  }
  function fixText(s) { try { return decodeURIComponent(escape(s)); } catch (e) { return s; } }
  function hhmm(s) { var m = /(\d{2}):(\d{2})/.exec(String(s || '')); return m ? fmtTime(+m[1], +m[2]) : ''; }
  function toMs(s) { var m = /^(\d{4})-(\d{2})-(\d{2})[ T](\d{2}):(\d{2})/.exec(String(s || '')); return m ? new Date(+m[1], +m[2] - 1, +m[3], +m[4], +m[5]).getTime() : 0; }
  function loadEpg(it) {
    text($('epg-now'), 'Carregando guia…'); text($('epg-time'), ''); text($('epg-next'), '');
    $('epg-fill').style.width = '0';
    if (S.mode !== 'xtream') { text($('epg-now'), 'Sem guia de programação para este canal.'); return; }
    api('epg', { stream_id: it.sid }, function (r) {
      if (!P.item || P.item.id !== it.id) { return; }
      if (!r.now) { text($('epg-now'), 'Sem guia de programação para este canal.'); return; }
      text($('epg-now'), fixText(r.now));
      var a = toMs(r.start), b = toMs(r.end);
      text($('epg-time'), hhmm(r.start) && hhmm(r.end) ? hhmm(r.start) + ' - ' + hhmm(r.end) : '');
      if (a && b > a) { $('epg-fill').style.width = Math.max(0, Math.min(100, (Date.now() - a) / (b - a) * 100)) + '%'; }
      if (r.next) { text($('epg-next'), 'A seguir: ' + fixText(r.next)); }
    }, function () { text($('epg-now'), 'Sem guia de programação para este canal.'); });
  }
  function fmtDate(iso) { var m = /^(\d{4})-(\d{2})-(\d{2})/.exec(String(iso || '')); return m ? m[3] + '/' + m[2] + '/' + m[1] : String(iso || '').substring(0, 10); }
  function fmtTime(h, m) {
    if (SET.clock24) { return two(h) + ':' + two(m); }
    return ((h % 12) || 12) + ':' + two(m) + (h < 12 ? ' AM' : ' PM');
  }

  // ================================================================ ABRIR ITEM
  function openItem(item, pl) {
    S.lastFocus[S.view] = focused;
    if (item.type === 'live' && !item.variants) {
      var full = findLoaded(item.id);         // favorito/recente: pega as qualidades se a pasta já carregou
      if (full) { item = full; }
    }
    if (item.type === 'live' || item.type === 'episode') {
      var w = watchOf(item.id);
      playItem(item, w && item.type !== 'live' ? w.pos : 0, pl || (focused && focused._pl) || null, 'full');
      return;
    }
    if (item.type === 'series') { showSeries(item); return; }
    showMovie(item);
  }
  /** Endereço do vídeo (favoritos e histórico não guardam a URL, que tem senha). */
  function urlFor(item, sid, done) {
    if (S.mode === 'm3u') {
      var found = null, tabs = ['live', 'movies', 'series'], t, i, j;
      for (t = 0; t < tabs.length && !found; t++) {
        var cats = S.cats[tabs[t]] || [];
        for (i = 0; i < cats.length && !found; i++) {
          var its = cats[i].items || [];
          for (j = 0; j < its.length; j++) { if (its[j].id === item.id) { found = its[j]; break; } }
        }
      }
      if (found && found.url) { done(found.url, null); } else { toast('Item não está mais na lista'); }
      return;
    }
    api('play_url', { type: item.type, sid: sid || item.sid }, function (r) {
      if (!r.url) { toast('Não consegui montar o endereço do vídeo'); return; }
      done(r.url, r.alt || null);
    }, function (msg) { toast(msg); });
  }

  // ---------- Detalhes ----------
  function openDetail(item, kind) {
    var im = $('dt-img');
    if (item.logo) { im.src = item.logo; im.style.display = ''; } else { im.removeAttribute('src'); im.style.display = 'none'; }
    $('dt-bg').style.backgroundImage = item.logo ? 'url("' + String(item.logo).replace(/"/g, '%22') + '")' : 'none';
    text($('dt-kind'), kind); text($('dt-title'), item.title);
    clear($('dt-seasons')); clear($('dt-eps'));
    on($('detail'), 'on');
  }
  function closeDetail() { off($('detail'), 'on'); focusFirst(S.lastFocus[S.view]); }
  function showMovie(item) {
    openDetail(item, 'FILME');
    text($('dt-meta'), item.rating && parseFloat(item.rating) > 0 ? '★ ' + parseFloat(item.rating).toFixed(1) : 'Filme');
    text($('dt-plot'), item.plot || '');
    buildDetailButtons(item, function () { var w = watchOf(item.id); playItem(item, w ? w.pos : 0, null, 'full'); }, watchOf(item.id));
    if (S.mode === 'xtream') {
      api('vod_info', { vod_id: item.sid }, function (r) {
        if (!has($('detail'), 'on')) { return; }
        var meta = [];
        if (r.rating) { meta.push('★ ' + r.rating); }
        if (r.year) { meta.push(r.year); }
        if (r.duration) { meta.push(r.duration); }
        if (r.genre) { meta.push(r.genre); }
        if (meta.length) { text($('dt-meta'), meta.join('   ·   ')); }
        if (r.plot) { text($('dt-plot'), r.plot); }
      }, function () {});
    }
  }
  function showSeries(item) {
    openDetail(item, 'SÉRIE');
    text($('dt-meta'), 'Série'); text($('dt-plot'), item.plot || '');
    buildDetailButtons(item, null, null);
    if (S.mode !== 'xtream') { $('dt-eps').appendChild(mk('p', 'empty', 'Esta lista não traz temporadas separadas.')); focusFirst(); return; }
    $('dt-eps').appendChild(mk('p', 'empty', 'Carregando temporadas…'));
    focusFirst();
    api('series_info', { series_id: item.sid }, function (r) {
      if (!has($('detail'), 'on')) { return; }
      if (r.plot) { text($('dt-plot'), r.plot); }
      var seasons = r.seasons || [];
      clear($('dt-eps'));
      if (!seasons.length) { $('dt-eps').appendChild(mk('p', 'empty', 'Nenhum episódio encontrado.')); focusFirst(); return; }
      text($('dt-meta'), seasons.length + (seasons.length > 1 ? ' temporadas' : ' temporada'));
      buildSeasons(item, seasons);
      addSeriesPlayButton(item, seasons);
    }, function (msg) { if (!has($('detail'), 'on')) { return; } clear($('dt-eps')); $('dt-eps').appendChild(mk('p', 'empty', msg)); focusFirst(); });
  }
  function buildSeasons(series, seasons) {
    var box = $('dt-seasons'), i;
    clear(box);
    for (i = 0; i < seasons.length; i++) {
      (function (s) { var b = mk('button', 'f season', 'Temporada ' + s.number); b.onclick = function () { pickSeason(series, seasons, s); }; b._season = s.number; box.appendChild(b); })(seasons[i]);
    }
    pickSeason(series, seasons, seasons[0], true);
  }
  function pickSeason(series, seasons, season, silent) {
    var btns = list(qsa('#dt-seasons .season')), i;
    for (i = 0; i < btns.length; i++) { if (btns[i]._season === season.number) { on(btns[i], 'sel'); } else { off(btns[i], 'sel'); } }
    var eps = season.episodes || [], items = eps2items(series, season, eps);
    longList($('dt-eps'), items, function (item, idx) {
      var ep = eps[idx], b = mk('button', 'f ep');
      b.appendChild(mk('b', null, 'E' + two(ep.number)));
      var t = mk('span', null, ep.title || ('Episódio ' + ep.number)), w = watchOf(item.id);
      if (w && w.dur > 0) { var bar = mk('div', 'bar'), fl = mk('i'); fl.style.width = Math.min(100, Math.round(w.pos / w.dur * 100)) + '%'; bar.appendChild(fl); t.appendChild(bar); }
      b.appendChild(t);
      b.onclick = function () { playItem(item, w ? w.pos : 0, items, 'full'); };
      b._item = item;
      return b;
    }, { exit: { up: function () { return qs('#dt-seasons .season.sel') || qs('#dt-btns .f'); } } });
    if (!silent) { focusFirst(qs('#dt-eps .ep')); }
  }
  function addSeriesPlayButton(series, seasons) {
    var w = watchAll(), i, j, k, pick = null, season = null, resume = 0;
    for (i = 0; i < w.length && !pick; i++) {
      if (w[i].parent !== series.id) { continue; }
      for (j = 0; j < seasons.length && !pick; j++) {
        var eps = seasons[j].episodes || [];
        for (k = 0; k < eps.length; k++) { if (eps[k].id === w[i].id) { pick = eps[k]; season = seasons[j]; resume = w[i].pos; break; } }
      }
    }
    if (!pick) { season = seasons[0]; pick = (season.episodes || [])[0]; resume = 0; }
    if (!pick) { return; }
    var items = eps2items(series, season, season.episodes || []), target = null;
    for (i = 0; i < items.length; i++) { if (items[i].id === pick.id) { target = items[i]; } }
    if (!target) { return; }
    var b = mk('button', 'f btn primary');
    b.innerHTML = ico('play');
    b.appendChild(mk('span', null, (resume > 30 ? 'Continuar T' : 'Assistir T') + season.number + 'E' + pick.number + (resume > 30 ? ' (' + clock(resume) + ')' : '')));
    b.onclick = function () { playItem(target, resume, items, 'full'); };
    var box = $('dt-btns');
    box.insertBefore(b, box.firstChild);
    setFocus(b);
  }
  function eps2items(series, season, eps) {
    var out = [], i;
    for (i = 0; i < eps.length; i++) {
      out.push({ id: eps[i].id, sid: eps[i].sid, type: 'episode', url: eps[i].url, logo: eps[i].logo || series.logo, parent: series.id, series: series.title,
        title: series.title + ' · T' + season.number + 'E' + eps[i].number + (eps[i].title ? ' — ' + eps[i].title : '') });
    }
    return out;
  }
  function buildDetailButtons(item, onPlay, watch) {
    var box = $('dt-btns');
    clear(box);
    if (onPlay) {
      var b = mk('button', 'f btn primary');
      b.innerHTML = ico('play');
      b.appendChild(mk('span', null, watch && watch.pos > 30 ? 'Continuar de ' + clock(watch.pos) : 'Assistir Agora'));
      b.onclick = onPlay;
      box.appendChild(b);
      if (watch && watch.pos > 30) { var b2 = mk('button', 'f btn', 'Começar do início'); b2.onclick = function () { playItem(item, 0, null, 'full'); }; box.appendChild(b2); }
    }
    var fv = mk('button', 'f btn');
    fv.innerHTML = ico('heart');
    var fl = mk('span', null, isFav(item.id) ? 'Remover dos favoritos' : 'Favoritar');
    fv.appendChild(fl);
    fv.onclick = function () { toggleFav(item); text(fl, isFav(item.id) ? 'Remover dos favoritos' : 'Favoritar'); };
    box.appendChild(fv);
    focusFirst();
  }

  // ================================================================ PLAYER
  var P = { item: null, playlist: null, index: -1, vIdx: -1, tried: {}, triedAlt: false, mixed: false, barTimer: 0, saveAt: 0, mode: '', stall: 0, url: '' };
  var V = null;
  var sleepTimer = 0;

  function alternateUrl(url) {
    var q = url.indexOf('?'), path = q < 0 ? url : url.substring(0, q), tail = q < 0 ? '' : url.substring(q), low = path.toLowerCase();
    function swap(a, b) { return path.substring(0, path.length - a.length) + b + tail; }
    if (/\.m3u8$/.test(low)) { return swap('.m3u8', '.ts'); }
    if (/\.ts$/.test(low)) { return swap('.ts', '.m3u8'); }
    if (/\.mp4$/.test(low)) { return swap('.mp4', '.mkv'); }
    if (/\.mkv$/.test(low)) { return swap('.mkv', '.mp4'); }
    return null;
  }
  /** "Formato do fluxo preferencial": troca .m3u8 por .ts nos canais quando o usuário pediu TS. */
  function prefFormat(url, item) {
    if (!url || item.type !== 'live') { return url; }
    var q = url.indexOf('?'), path = q < 0 ? url : url.substring(0, q);
    if (SET.format === 'ts' && /\.m3u8$/i.test(path)) { return alternateUrl(url) || url; }
    if (SET.format === 'hls' && /\.ts$/i.test(path)) { return alternateUrl(url) || url; }
    return url;
  }
  function isMixed(url) { return location.protocol === 'https:' && url.substring(0, 7).toLowerCase() === 'http://'; }
  function upgrade(url) { return 'https://' + url.substring(7); }

  function placeMini() {
    var pv = $('preview').getBoundingClientRect(), pl = $('player');
    pl.style.left = pv.left + 'px'; pl.style.top = pv.top + 'px';
    pl.style.width = pv.width + 'px'; pl.style.height = pv.height + 'px';
  }
  /** Dentro do APK de Android TV o vídeo toca no player NATIVO do Android
      (toca H265, 4K e TS, que o navegador interno não toca). */
  function NATIVE() { return !!(window.__nativePlayer && window.AtivaBridge); }
  function post(o) { try { window.AtivaBridge.postMessage(JSON.stringify(o)); } catch (e) {} }
  function setPlayerMode(mode) {
    var pl = $('player');
    if (NATIVE() && mode) { P.mode = 'native'; off(pl, 'mini'); off(pl, 'full'); return; }
    P.mode = mode;
    off(pl, 'mini'); off(pl, 'full'); off($('pl-menu'), 'on');
    if (mode === 'mini') { on(pl, 'mini'); placeMini(); text($('preview-title'), P.item ? P.item.title : ''); }
    else if (mode === 'full') { pl.style.left = pl.style.top = pl.style.width = pl.style.height = ''; on(pl, 'full'); }
  }
  function goFull() { setPlayerMode('full'); showBar(); }

  function playItem(item, start, playlist, mode) {
    P.item = item;
    P.playlist = playlist || null;
    P.index = -1; P.tried = {}; P.triedAlt = false; P.saveAt = 0;
    if (P.playlist) { var i; for (i = 0; i < P.playlist.length; i++) { if (P.playlist[i].id === item.id) { P.index = i; } } }
    P.vIdx = pickVariantIdx(item);
    setPlayerMode(mode || 'full');
    text($('pl-title'), item.title);
    $('pl-live').style.display = item.type === 'live' ? '' : 'none';
    text($('pl-hint'), item.type === 'live' ? 'OK mostra os controles · ▲ ▼ troca de canal · Voltar sai' : 'OK mostra os controles · ◀ ▶ avança 10s · Voltar sai');
    scrubEnd(false);
    updateCtrls();
    if (item.type === 'live') { addRecent(item); }
    startStream(start || 0);
  }
  /** Toca a resolução P.vIdx (ou o endereço único do item). */
  function startStream(start) {
    var item = P.item, v = P.vIdx >= 0 && item.variants ? item.variants[P.vIdx] : null;
    text($('pl-q'), v && item.type === 'live' ? v.label : '');
    off($('pl-err'), 'on'); on($('pl-spin'), 'on');
    if (P.mode === 'full') { showBar(); }
    var url = v ? v.url : item.url, sid = v ? v.sid : item.sid;
    function go(u, alt) {
      if (P.item !== item) { return; }
      if (v) { v.url = u; } else { item.url = u; if (alt) { item.alt = alt; } }
      u = prefFormat(u, item);
      P.url = u;
      if (P.mode === 'native') {
        var labels = [], j;
        for (j = 0; item.variants && j < item.variants.length; j++) { labels.push(item.variants[j].label); }
        post({ cmd: 'play', url: u, alt: alternateUrl(u), title: item.title, live: item.type === 'live',
               start: item.type === 'live' ? 0 : (start || 0), quality: v ? v.label : '', qualities: labels,
               vIdx: P.vIdx, hasPrev: hasPrevItem(), hasNext: hasNextItem() });
        return;
      }
      P.mixed = isMixed(u);
      V.src = P.mixed ? upgrade(u) : u;
      V._start = item.type === 'live' ? 0 : (start || 0);
      try { V.load(); } catch (e) {}
      var p = V.play();
      if (p && p['catch']) { p['catch'](function () {}); }
    }
    if (url) { go(url, null); } else { urlFor(item, sid, go); }
  }
  /** Troca de resolução (menu do player ou troca automática). */
  function switchVariant(idx, manual) {
    if (!P.item || !P.item.variants || idx < 0 || idx >= P.item.variants.length) { return; }
    var pos = P.item.type === 'live' ? 0 : (P.mode === 'native' ? (P.nativePos || 0) : (V ? V.currentTime : 0));
    P.vIdx = idx;
    P.triedAlt = false;
    if (manual) {
      var vq = getJson('ativa.vq', {});
      vq[P.item.id] = P.item.variants[idx].label;
      setJson('ativa.vq', vq);
    }
    toast((manual ? 'Qualidade: ' : 'Canal travou — trocando para ') + P.item.variants[idx].label);
    startStream(pos);
  }
  /** Troca automática em caso de falha: próxima resolução ainda não tentada. */
  function failover() {
    if (!SET.failover || !P.item || !P.item.variants || P.item.variants.length < 2) { return false; }
    P.tried[P.vIdx] = true;
    var n = P.item.variants.length, k;
    for (k = 1; k < n; k++) {
      var j = (P.vIdx + k) % n;
      if (!P.tried[j]) { switchVariant(j, false); return true; }
    }
    return false;
  }

  function stopPlayer() {
    if (P.mode === 'native') { post({ cmd: 'close' }); P.item = null; P.playlist = null; P.mode = ''; return; }
    if (P.item && V && V.duration) { saveWatch(P.item, V.currentTime, V.duration); }
    try { V.pause(); } catch (e) {}
    V.removeAttribute('src');
    try { V.load(); } catch (e) {}
    clearStall();
    setPlayerMode('');
    hideCtrls();
    off($('pl-spin'), 'on'); off($('pl-err'), 'on');
    P.item = null; P.playlist = null;
    text($('preview-title'), '');
  }
  function stopMini() { if (P.mode === 'mini') { stopPlayer(); } }
  function leaveFull() {
    off($('pl-menu'), 'on');
    if (S.view === 'live' && P.item && P.item.type === 'live' && has($('main'), 'on') && !has($('detail'), 'on')) {
      setPlayerMode('mini');
      focusFirst(qs('#live-list .chan.playing') || S.lastFocus.live);
      return;
    }
    stopPlayer();
    if (has($('detail'), 'on')) { focusFirst(); } else { focusFirst(S.lastFocus[S.view]); }
  }
  function showBar() {
    on($('pl-bar'), 'on');
    if (P.barTimer) { clearTimeout(P.barTimer); }
    P.barTimer = setTimeout(function () { if (!has($('pl-menu'), 'on') && !ctrlOn()) { off($('pl-bar'), 'on'); } }, (SET.infoBar || 5) * 1000);
  }
  function zap(step) {
    if (!P.playlist || P.index < 0) { return; }
    var n = P.index + step;
    if (n < 0 || n >= P.playlist.length) { return; }
    playItem(P.playlist[n], 0, P.playlist, P.mode || 'full');
    if (S.view === 'live') { loadEpg(P.playlist[n]); }
  }
  function nextEpisode() {
    if (!P.playlist || P.index < 0 || P.index + 1 >= P.playlist.length) { return false; }
    playItem(P.playlist[P.index + 1], 0, P.playlist, 'full');
    toast('Reproduzindo próximo episódio...');
    return true;
  }
  function prevEpisode() {
    if (!P.playlist || P.index <= 0) { return false; }
    playItem(P.playlist[P.index - 1], 0, P.playlist, 'full');
    return true;
  }
  function hasPrevItem() { return !!(P.playlist && P.index > 0 && P.item && P.item.type !== 'movie'); }
  function hasNextItem() { return !!(P.playlist && P.index >= 0 && P.index + 1 < P.playlist.length && P.item && P.item.type !== 'movie'); }

  // ---------- barra de controle (Anterior / Pausar / Próximo / Qualidade) ----------
  function ctrlOn() { return has($('player'), 'ctrl'); }
  function updateCtrls() {
    var live = P.item && P.item.type === 'live', paused = V && V.paused && P.mode !== 'native';
    var pp = $('pc-play');
    pp.innerHTML = ico(paused ? 'play' : 'pause');
    pp.appendChild(mk('span', null, paused ? 'Continuar' : 'Pausar'));
    $('pc-prev').hidden = !hasPrevItem();
    $('pc-next').hidden = !hasNextItem();
    text(qs('#pc-prev span'), live ? 'Canal anterior' : 'Anterior');
    text(qs('#pc-next span'), live ? 'Próximo canal' : 'Próximo');
    $('pc-opts').hidden = !live;            // filmes e séries: uma qualidade só
    var sk = $('pl-seek'), vod = !live && isFinite(V.duration) && V.duration > 0;
    if (vod) { on(sk, 'f'); on(sk, 'vod'); } else { off(sk, 'f'); off(sk, 'vod'); off(sk, 'on'); }
  }

  // ---------- barra de tempo com bolinha (igual Netflix/YouTube) ----------
  // Controle: ▲ até a barra, ◀ ▶ arrasta a bolinha, OK pula para lá.
  // Mouse (PC / Magic Remote da LG): arrasta a bolinha e solta.
  var SCR = { on: false, pos: 0, t: 0, last: 0, hold: 0 };
  function seekDur() { return V && isFinite(V.duration) && V.duration > 0 ? V.duration : 0; }
  function drawSeek(pos) {
    var d = seekDur(), pc = d > 0 ? Math.max(0, Math.min(100, pos / d * 100)) : 100;
    $('pl-fill').style.width = pc + '%';
    $('pl-knob').style.left = pc + '%';
    text($('pl-time'), clock(pos));
  }
  function scrubBy(dir) {
    var d = seekDur(); if (!d) { return; }
    var now = Date.now();
    SCR.hold = (now - SCR.last < 350) ? SCR.hold + 1 : 0;   // segurou: vai mais rápido
    SCR.last = now;
    var step = SCR.hold > 20 ? 60 : SCR.hold > 8 ? 30 : 10;
    if (!SCR.on) { SCR.on = true; SCR.pos = V.currentTime || 0; on($('pl-seek'), 'scrub'); }
    SCR.pos = Math.max(0, Math.min(d - 2, SCR.pos + dir * step));
    drawSeek(SCR.pos);
    if (SCR.t) { clearTimeout(SCR.t); }
    SCR.t = setTimeout(function () { scrubEnd(true); }, 2500);  // parou de mexer: pula sozinho
  }
  function scrubEnd(apply) {
    if (SCR.t) { clearTimeout(SCR.t); SCR.t = 0; }
    if (!SCR.on) { return; }
    SCR.on = false; off($('pl-seek'), 'scrub');
    if (apply && seekDur()) { try { V.currentTime = SCR.pos; } catch (e) {} }
    drawSeek(apply ? SCR.pos : (V.currentTime || 0));
  }
  function wireSeek() {
    var sk = $('pl-seek'), drag = false;
    function at(x) { var r = sk.getBoundingClientRect(); return Math.max(0, Math.min(1, (x - r.left) / (r.width || 1))) * seekDur(); }
    function px(e) { return e.touches && e.touches.length ? e.touches[0].clientX : (e.changedTouches && e.changedTouches.length ? e.changedTouches[0].clientX : e.clientX); }
    function start(e) {
      if (!seekDur() || (P.item && P.item.type === 'live')) { return; }
      drag = true; SCR.on = true; on(sk, 'drag'); on(sk, 'scrub');
      SCR.pos = at(px(e)); drawSeek(SCR.pos); showBar(); if (ctrlOn()) { ctrlKeepAlive(); }
      if (e.preventDefault) { e.preventDefault(); }
    }
    function moveTo(e) { if (!drag) { return; } SCR.pos = at(px(e)); drawSeek(SCR.pos); showBar(); }
    function end() { if (!drag) { return; } drag = false; off(sk, 'drag'); scrubEnd(true); }
    sk.addEventListener('mousedown', start);
    document.addEventListener('mousemove', moveTo);
    document.addEventListener('mouseup', end);
    sk.addEventListener('touchstart', start);
    document.addEventListener('touchmove', moveTo);
    document.addEventListener('touchend', end);
    sk.onclick = function () { if (SCR.on) { scrubEnd(true); } };   // OK do controle confirma
  }
  var ctrlTimer = 0;
  function ctrlKeepAlive() {
    if (ctrlTimer) { clearTimeout(ctrlTimer); }
    ctrlTimer = setTimeout(function () {
      if (!has($('pl-menu'), 'on')) { hideCtrls(); off($('pl-bar'), 'on'); }
    }, ((SET.infoBar || 5) + 5) * 1000);
  }
  function showCtrls() {
    updateCtrls();
    if (has($('pl-seek'), 'f')) { text($('pl-hint'), '▲ barra de tempo (◀ ▶ e OK) · Voltar esconde'); }
    on($('player'), 'ctrl');
    on($('pl-bar'), 'on');
    if (P.barTimer) { clearTimeout(P.barTimer); }
    ctrlKeepAlive();
    setFocus($('pc-play'));
  }
  function hideCtrls() {
    scrubEnd(true);
    if (P.item && P.item.type !== 'live') { text($('pl-hint'), 'OK mostra os controles · ◀ ▶ avança 10s · Voltar sai'); }
    off($('player'), 'ctrl');
    if (ctrlTimer) { clearTimeout(ctrlTimer); ctrlTimer = 0; }
    if (focused && $('player').contains(focused)) { off(focused, 'on'); focused = null; }
  }
  function wireCtrls() {
    $('pc-play').onclick = function () {
      if (V.paused) { try { V.play(); } catch (e) {} } else { V.pause(); }
      updateCtrls(); setFocus($('pc-play')); ctrlKeepAlive();
    };
    $('pc-prev').onclick = function () {
      if (P.item && P.item.type === 'live') { zap(-1); } else { prevEpisode(); }
      showCtrls(); if (!$('pc-prev').hidden) { setFocus($('pc-prev')); }
    };
    $('pc-next').onclick = function () {
      if (P.item && P.item.type === 'live') { zap(1); } else { nextEpisode(); }
      showCtrls(); if (!$('pc-next').hidden) { setFocus($('pc-next')); }
    };
    $('pc-opts').onclick = function () { openPlayerMenu(); };
  }

  // ---------- respostas do player nativo (APK de Android TV) ----------
  window.__native = {
    closed: function (pos, dur) {
      if (P.item && dur > 0) { saveWatch(P.item, pos, dur); }
      P.item = null; P.playlist = null; P.mode = '';
      if (has($('detail'), 'on')) { focusFirst(); } else { focusFirst(S.lastFocus[S.view]); }
    },
    progress: function (pos, dur) {
      P.nativePos = pos;
      if (P.item && dur > 0 && pos - P.saveAt > 12) { P.saveAt = pos; saveWatch(P.item, pos, dur); }
    },
    next: function () { if (P.item && P.item.type === 'live') { zap(1); } else { nextEpisode(); } },
    prev: function () { if (P.item && P.item.type === 'live') { zap(-1); } else { prevEpisode(); } },
    quality: function (i) { switchVariant(i, true); },
    ended: function () { if (P.item && P.item.type === 'episode' && nextEpisode()) { return; } post({ cmd: 'close' }); },
    error: function () {
      if (failover()) { return; }
      post({ cmd: 'error', text: 'Não foi possível tocar este canal. Tente outra qualidade ou outro canal. Se repetir em tudo, fale com o suporte: ' + SUPORTE + '.' });
    }
  };
  function clearStall() { if (P.stall) { clearTimeout(P.stall); P.stall = 0; } }

  // ---------- menu do player (qualidade) ----------
  function openPlayerMenu() {
    var main = $('pl-menu-main'), ql = $('pl-q-list'), item = P.item;
    clear(main); clear(ql);
    var pp = mk('button', 'f pmi');
    pp.innerHTML = ico(V.paused ? 'play' : 'pause');
    pp.appendChild(mk('span', null, V.paused ? 'Continuar' : 'Pausar'));
    pp.onclick = function () { if (V.paused) { try { V.play(); } catch (e) {} } else { V.pause(); } closePlayerMenu(); };
    main.appendChild(pp);
    var fv = mk('button', 'f pmi');
    fv.innerHTML = ico('heart');
    fv.appendChild(mk('span', null, isFav(item.id) ? 'Remover dos favoritos' : 'Favoritar'));
    fv.onclick = function () { toggleFav(item); closePlayerMenu(); };
    main.appendChild(fv);
    var vars = item.variants || [];
    $('pl-q-title').style.display = '';
    if (vars.length > 1) {
      text($('pl-q-title'), 'Qualidade (' + vars.length + ')');
      var i;
      for (i = 0; i < vars.length; i++) {
        (function (idx) {
          var b = mk('button', 'f pmi' + (idx === P.vIdx ? ' sel' : ''));
          b.innerHTML = ico('hd');
          b.appendChild(mk('span', null, vars[idx].label));
          if (idx === 0) { b.appendChild(mk('em', null, 'melhor')); }
          b.onclick = function () { closePlayerMenu(); if (idx !== P.vIdx) { switchVariant(idx, true); } };
          ql.appendChild(b);
        })(i);
      }
    } else {
      text($('pl-q-title'), 'Qualidade');
      ql.appendChild(mk('p', 'shint', 'Este canal tem uma qualidade só.'));
    }
    on($('pl-menu'), 'on');
    on($('pl-bar'), 'on');
    setFocus(qs('#pl-q-list .pmi.sel') || pp);
  }
  function closePlayerMenu() {
    off($('pl-menu'), 'on'); showBar();
    if (focused) { off(focused, 'on'); } focused = null;
    if (ctrlOn()) { setFocus($('pc-opts')); ctrlKeepAlive(); }
  }

  function wirePlayer() {
    V = $('video');
    V.addEventListener('loadedmetadata', function () {
      off($('pl-spin'), 'on');
      if (V._start > 1 && isFinite(V.duration) && V.duration > 0) { try { V.currentTime = Math.min(V._start, V.duration - 10); } catch (e) {} }
    });
    V.addEventListener('waiting', function () {
      on($('pl-spin'), 'on');
      clearStall();
      // Travou por X segundos? Troca sozinho de resolução.
      if (SET.failover) { P.stall = setTimeout(function () { P.stall = 0; if (V.readyState < 3) { failover(); } }, (SET.failWait || 15) * 1000); }
    });
    V.addEventListener('playing', function () { off($('pl-spin'), 'on'); off($('pl-err'), 'on'); clearStall(); if (ctrlOn()) { updateCtrls(); } });
    V.addEventListener('pause', function () { if (ctrlOn()) { updateCtrls(); } });
    wireCtrls();
    wireSeek();
    V.addEventListener('durationchange', function () { if (ctrlOn()) { updateCtrls(); } });
    V.addEventListener('timeupdate', function () {
      if (P.mode !== 'full') { return; }
      var d = isFinite(V.duration) && V.duration > 0 ? V.duration : 0, pos = V.currentTime || 0;
      if (d > 0) { text($('pl-dur'), clock(d)); } else { text($('pl-dur'), 'AO VIVO'); }
      if (!SCR.on) { drawSeek(pos); }
      if (d > 0 && pos - P.saveAt > 12) { P.saveAt = pos; saveWatch(P.item, pos, d); }
    });
    V.addEventListener('ended', function () {
      if (P.item && P.item.type === 'episode' && nextEpisode()) { return; }
      leaveFull();
    });
    V.addEventListener('error', function () {
      off($('pl-spin'), 'on');
      if (!P.item || !V.getAttribute('src')) { return; }
      if (P.mixed && P.url) { P.mixed = false; V.src = P.url; try { V.load(); V.play(); } catch (e) {} return; }
      if (!P.triedAlt) {
        var alt = alternateUrl(P.url || '');
        if (alt) { P.triedAlt = true; P.url = alt; V.src = alt; try { V.load(); V.play(); } catch (e) {} return; }
      }
      if (failover()) { return; }
      text($('pl-err'), 'Não foi possível tocar este canal. Tente outra qualidade (OK → Qualidade) ou outro canal. Se repetir em tudo, fale com o suporte: ' + SUPORTE + '.');
      on($('pl-err'), 'on');
      if (P.mode === 'full') { showBar(); }
    });
  }

  // ================================================================ TECLAS
  function keyName(e) {
    var k = e.keyCode;
    if (k === 37) { return 'left'; }
    if (k === 39) { return 'right'; }
    if (k === 38) { return 'up'; }
    if (k === 40) { return 'down'; }
    if (k === 13 || k === 32) { return 'ok'; }
    if (k === 10009 || k === 461 || k === 27 || k === 8 || k === 166) { return 'back'; }
    if (k === 415 || k === 19 || k === 179 || k === 10252) { return 'playpause'; }
    if (k === 417 || k === 228) { return 'ff'; }
    if (k === 412 || k === 227) { return 'rw'; }
    if (k === 413 || k === 178) { return 'stop'; }
    if (k === 427 || k === 33) { return 'chup'; }
    if (k === 428 || k === 34) { return 'chdown'; }
    if (k === 457) { return 'info'; }
    if (k >= 48 && k <= 57) { return 'n' + (k - 48); }
    return '';
  }
  var okAt = 0, okLong = false, backAt = 0;
  function onKeyDown(e) {
    var k = keyName(e);
    if (!k) { return; }
    if (e.type && window.AtivaBridge && dedupe(e.keyCode, false, 'page')) { e.preventDefault(); return; }
    e.preventDefault();
    // Janelas por cima de tudo
    if (PIN) {
      if (k === 'back') { closePin(); return; }
      if (k.charAt(0) === 'n' && k.length === 2) { if (PIN.value.length < 4) { PIN.value += k.charAt(1); pinDots(); if (PIN.value.length === 4) { setTimeout(pinSubmit, 120); } } return; }
    } else if (KB) {
      if (k === 'back') { closeKeyboard(false); return; }
    } else if (has($('player'), 'full')) {
      if (has($('pl-menu'), 'on')) {
        if (k === 'back') { closePlayerMenu(); return; }
      } else if (playerKey(k)) { return; }
    }
    if (k === 'ok') {
      if (!okAt) { okAt = Date.now(); okLong = false; }
      else if (!okLong && Date.now() - okAt > 650) { okLong = true; if (focused && focused._fav) { focused._fav(); } }
      return;
    }
    if (k === 'info') { if (focused && focused._fav) { focused._fav(); } return; }
    if (k === 'back') { goBack(); return; }
    if ((k === 'chup' || k === 'chdown') && P.mode === 'mini') { zap(k === 'chup' ? -1 : 1); return; }
    if (k === 'chup') { move('up'); return; }
    if (k === 'chdown') { move('down'); return; }
    if (k === 'playpause' && P.mode === 'mini') { if (V.paused) { V.play(); } else { V.pause(); } return; }
    if (k === 'left' || k === 'right' || k === 'up' || k === 'down') { move(k); }
  }
  function onKeyUp(e) {
    var k = keyName(e);
    if (k !== 'ok') { return; }
    if (e.type && window.AtivaBridge && dedupe(e.keyCode, true, 'page')) { return; }
    // O OK que ABRIU o menu do player não pode também escolher a opção ao soltar.
    if (P.menuJust) { P.menuJust = false; okAt = 0; okLong = false; return; }
    if (has($('player'), 'full') && !has($('pl-menu'), 'on') && !ctrlOn() && !PIN && !KB) { okAt = 0; okLong = false; return; }
    if (!okLong && focused) { focused.click(); }
    okAt = 0; okLong = false;
  }
  /** Tecla no player em tela cheia. true = tratada aqui; false = segue o fluxo
      normal (andar/clicar nos botões da barra de controle). */
  function playerKey(k) {
    var live = P.item && P.item.type === 'live';
    if (ctrlOn()) {
      ctrlKeepAlive();
      if (k === 'back' && SCR.on) { scrubEnd(false); return true; }
      if (k === 'back') { hideCtrls(); showBar(); return true; }
      if (focused === $('pl-seek') && (k === 'left' || k === 'right' || k === 'rw' || k === 'ff')) {
        scrubBy(k === 'left' || k === 'rw' ? -1 : 1); return true;
      }
      if (focused === $('pl-seek') && (k === 'up' || k === 'down')) { scrubEnd(true); }
      if (k === 'ok' || k === 'left' || k === 'right') { return false; }
      if (k === 'up' || k === 'down') { if (has($('pl-seek'), 'f')) { move(k); return true; } }
    } else {
      if (k === 'back' || k === 'stop') { leaveFull(); return true; }
      if (k === 'ok') { P.menuJust = true; showCtrls(); return true; }
    }
    if (k === 'stop') { leaveFull(); return true; }
    if (k === 'playpause') { showBar(); if (V.paused) { try { V.play(); } catch (e) {} } else { V.pause(); } updateCtrls(); return true; }
    if (k === 'up' || k === 'chup') { if (live) { zap(-1); } else { showBar(); } return true; }
    if (k === 'down' || k === 'chdown') { if (live) { zap(1); } else { showBar(); } return true; }
    if (k === 'left' || k === 'rw' || k === 'right' || k === 'ff') {
      showBar();
      if (live || !isFinite(V.duration) || V.duration <= 0) { return true; }
      var step = (k === 'left') ? -10 : (k === 'right') ? 10 : (k === 'ff' ? 60 : -60);
      try { V.currentTime = Math.max(0, Math.min(V.duration - 2, V.currentTime + step)); } catch (e) {}
      return true;
    }
    return true;
  }
  function goBack() {
    if (has($('detail'), 'on')) { closeDetail(); return; }
    if (has($('settings'), 'on')) { closeSettings(); return; }
    if (has($('profiles'), 'on')) {
      if (has($('prof-list'), 'editing')) { toggleProfEdit(); return; }
      if (S.catalogReady && S.wasInMain) { openMain(); }
      return;
    }
    if (has($('activate'), 'on') || has($('boot'), 'on')) { return; }
    if (S.view === 'grid' || S.view === 'search' || S.view === 'continue' || S.view === 'favorites') { setView(S.prevView || 'home'); return; }
    if (S.view !== 'home') { setView('home'); return; }
    if (Date.now() - backAt < 3000) { exitApp(); return; }
    backAt = Date.now();
    toast('Aperte Voltar de novo para sair');
  }
  function exitApp() {
    // Dentro do APK de Android TV: quem fecha o app é o lado Android.
    try { if (window.AtivaBridge) { window.AtivaBridge.postMessage('exit'); return; } } catch (e) {}
    try { if (window.tizen && window.tizen.application) { window.tizen.application.getCurrentApplication().exit(); return; } } catch (e) {}
    try { if (window.webOS && window.webOS.platformBack) { window.webOS.platformBack(); return; } } catch (e) {}
    try { window.close(); } catch (e) {}
  }
  function registerTvKeys() {
    try {
      if (window.tizen && window.tizen.tvinputdevice) {
        var keys = ['MediaPlayPause', 'MediaPlay', 'MediaPause', 'MediaStop', 'MediaFastForward', 'MediaRewind', 'ChannelUp', 'ChannelDown', 'Info', '0', '1', '2', '3', '4', '5', '6', '7', '8', '9'], i;
        for (i = 0; i < keys.length; i++) { try { window.tizen.tvinputdevice.registerKey(keys[i]); } catch (e) {} }
      }
    } catch (e) {}
  }

  // ================================================================ PERFIS
  function showProfiles() {
    showScreen('profiles');
    off($('prof-list'), 'editing');
    text($('prof-title'), 'Quem está assistindo?');
    text($('prof-edit'), 'Editar perfis');
    text($('prof-dev'), D.mac + '  ·  ' + prettyKey(D.key));
    renderProfiles();
  }
  function renderProfiles() {
    var box = $('prof-list'), ps = profiles(), i, editing = has(box, 'editing');
    clear(box);
    for (i = 0; i < ps.length; i++) {
      (function (p, idx) {
        var b = mk('button', 'f prof'), av = mk('div', 'av');
        if (idx === 0) { var pl = mk('div', 'play'); pl.innerHTML = ico('play'); av.appendChild(pl); }
        else { av.style.background = p.color || COLORS[idx % COLORS.length]; av.appendChild(mk('span', 'ini', initials(p.name))); }
        av.appendChild(mk('span', 'edit-mark', '✎'));
        b.appendChild(av);
        b.appendChild(mk('span', null, p.name));
        b.onclick = function () { if (has(box, 'editing')) { editProfile(p); } else { chooseProfile(p); } };
        box.appendChild(b);
      })(ps[i], i);
    }
    if (ps.length < 5 && !editing) {
      var add = mk('button', 'f prof'), av2 = mk('div', 'av');
      av2.appendChild(mk('span', 'plus', '+'));
      add.appendChild(av2);
      add.appendChild(mk('span', null, 'Adicionar perfil'));
      add.onclick = function () {
        openKeyboard('Nome do novo perfil', '', function (name) {
          if (!name) { return; }
          var list2 = profiles();
          list2.push({ id: 'p' + Date.now(), name: name, color: COLORS[list2.length % COLORS.length] });
          setJson('ativa.profiles', list2);
          renderProfiles();
          toast('Perfil “' + name + '” criado');
        });
      };
      box.appendChild(add);
    }
    var cur = null, kids = list(box.children), j;
    for (j = 0; j < ps.length; j++) { if (ps[j].id === PROF) { cur = kids[j]; } }
    focusFirst(cur || kids[0]);
  }
  function toggleProfEdit() {
    var box = $('prof-list');
    if (has(box, 'editing')) { off(box, 'editing'); text($('prof-title'), 'Quem está assistindo?'); text($('prof-edit'), 'Editar perfis'); }
    else { on(box, 'editing'); text($('prof-title'), 'Escolha o perfil para editar'); text($('prof-edit'), 'Pronto'); }
    renderProfiles();
  }
  function editProfile(p) {
    openKeyboard('Renomear perfil (apague tudo e confirme para excluir)', p.name, function (name) {
      var ps = profiles(), i;
      for (i = 0; i < ps.length; i++) {
        if (ps[i].id !== p.id) { continue; }
        if (!name) {
          if (ps.length === 1) { toast('Precisa ficar pelo menos um perfil'); return; }
          ps.splice(i, 1);
          store.del('ativa.fav.' + p.id); store.del('ativa.watch.' + p.id); store.del('ativa.recent.' + p.id);
          if (PROF === p.id) { PROF = ps[0].id; store.set('ativa.profile', PROF); }
          toast('Perfil excluído');
        } else { ps[i].name = name; toast('Perfil renomeado'); }
        break;
      }
      setJson('ativa.profiles', ps);
      renderProfiles();
    });
  }
  function chooseProfile(p) {
    PROF = p.id;
    store.set('ativa.profile', PROF);
    if (S.catalogReady) { openMain(); }
    else { S.wantMain = true; showScreen('boot'); text($('boot-msg'), 'Carregando o catálogo…'); }
  }

  // ================================================================ CONFIGURAÇÕES
  var SECTIONS = [
    ['account', 'user', 'Informações da conta'], ['security', 'lock', 'Segurança'], ['parental', 'family', 'Controle parental'],
    ['restrict', 'block', 'Restrições'], ['playback', 'play', 'Reprodução'], ['present', 'palette', 'Apresentação'],
    ['data', 'cloud', 'Dados'], ['history', 'history', 'Histórico de assistidos'], ['favs', 'heart', 'Gerenciar favoritos'],
    ['cats', 'folder', 'Gerenciar categorias'], ['about', 'info', 'Acerca de'], ['back', 'back', 'Voltar']
  ];
  var SETS = { sec: 'account', catTab: 'live' };
  function openSettings() {
    if (focused) { S.lastFocus[S.view] = focused; }
    stopMini();
    showScreen('settings');
    var box = $('set-menu'), i;
    clear(box);
    for (i = 0; i < SECTIONS.length; i++) {
      (function (s) {
        var b = mk('button', 'f smi');
        b.innerHTML = ico(s[1]);
        b.appendChild(mk('span', null, s[2]));
        b._sec = s[0];
        b.onclick = function () { if (s[0] === 'back') { closeSettings(); return; } openSection(s[0], true); };
        // Andar pelo menu já mostra a seção ao lado (como no app).
        b._onFocus = function () { if (s[0] !== 'back' && SETS.sec !== s[0]) { openSection(s[0], false); } };
        box.appendChild(b);
      })(SECTIONS[i]);
    }
    openSection(SETS.sec, false);
    focusFirst(qs('#set-menu .smi.sel'));
  }
  function closeSettings() {
    showScreen('main');
    var v = S.view;
    if (!v || v === 'grid' || v === 'search' || v === 'settings') { v = S.prevView || 'home'; }
    setView(v);
  }
  function openSection(sec, focusBody) {
    SETS.sec = sec;
    var btns = list($('set-menu').children), i, title = '';
    for (i = 0; i < btns.length; i++) { if (btns[i]._sec === sec) { on(btns[i], 'sel'); title = btns[i].textContent; } else { off(btns[i], 'sel'); } }
    text($('set-title'), title);
    var body = $('set-body');
    clear(body);
    body.scrollTop = 0;
    SECTION_RENDER[sec](body);
    if (focusBody) { focusFirst(qs('#set-body .f')); }
  }
  function redraw() {
    var keep = focused && focused._key;
    openSection(SETS.sec, false);
    if (keep) { var el = qs('#set-body [data-k="' + keep + '"]'); if (el) { setFocus(el); return; } }
    focusFirst(qs('#set-body .f'));
  }
  // --- construtores de linhas ---
  function sInfo(body, icon, label, value) {
    var r = mk('div', 'srow');
    r.innerHTML = ico(icon);
    var lab = mk('div', 'lab'); lab.appendChild(mk('b', null, label)); r.appendChild(lab);
    r.appendChild(mk('span', 'val', value));
    body.appendChild(r);
    return r;
  }
  function sAction(body, key, icon, label, sub, fn, avatar) {
    var r = mk('button', 'f srow');
    r.setAttribute('data-k', key); r._key = key;
    if (avatar) { var av = mk('span', 'av'); av.innerHTML = ico(icon); r.appendChild(av); } else { r.innerHTML = ico(icon); }
    var lab = mk('div', 'lab'); lab.appendChild(mk('b', null, label)); if (sub) { lab.appendChild(mk('small', null, sub)); }
    r.appendChild(lab);
    r.appendChild(mk('span', 'chev', '›'));
    r.onclick = fn;
    body.appendChild(r);
    return r;
  }
  function sToggle(body, key, label, sub, value, fn) {
    var r = mk('button', 'f srow');
    r.setAttribute('data-k', key); r._key = key;
    var lab = mk('div', 'lab'); lab.appendChild(mk('b', null, label)); if (sub) { lab.appendChild(mk('small', null, sub)); }
    r.appendChild(lab);
    r.appendChild(mk('span', 'toggle' + (value ? ' yes' : '')));
    r.onclick = fn;
    body.appendChild(r);
    return r;
  }
  function sChoice(body, key, label, sub, opts, value, fn, inline) {
    var g = mk('div', 'sgroup');
    g.appendChild(mk('b', null, label));
    if (sub) { g.appendChild(mk('small', null, sub)); }
    var box = mk('div', 'sopts' + (inline ? ' inline' : '')), i;
    for (i = 0; i < opts.length; i++) {
      (function (o) {
        var b = mk('button', 'f sopt' + (o[0] === value ? ' sel' : ''), o[1]);
        b.setAttribute('data-k', key + '=' + o[0]); b._key = key + '=' + o[0];
        b.onclick = function () { fn(o[0]); };
        box.appendChild(b);
      })(opts[i]);
    }
    g.appendChild(box);
    body.appendChild(g);
  }
  function sHint(body, t) { body.appendChild(mk('p', 'shint', t)); }
  function set(k, v) { SET[k] = v; saveSet(); }

  var SECTION_RENDER = {
    account: function (b) {
      sInfo(b, 'check', 'Assinatura', S.status === 'trial' ? 'Teste' : 'Plano ativo');
      sInfo(b, 'clock', 'Data de expiração', S.expires ? fmtDate(S.expires) : '—');
      sInfo(b, 'chip', 'Endereço MAC', D.mac);
      sInfo(b, 'key', 'Código-chave', prettyKey(D.key));
      sInfo(b, 'list', 'Lista em uso', S.mode === 'm3u' ? 'Lista M3U' : S.mode === 'xtream' ? 'Painel Xtream' : 'Nenhuma');
      var p = null, ps = profiles(), i;
      for (i = 0; i < ps.length; i++) { if (ps[i].id === PROF) { p = ps[i]; } }
      sAction(b, 'profile', 'play', 'Trocar perfil', p ? p.name : '', function () { stopPlayer(); S.wasInMain = true; showProfiles(); }, true);
      sAction(b, 'logout', 'power', 'Desconectar este aparelho', 'Gera um novo MAC e chave. Precisa ativar de novo no painel.', function () {
        askPin('Confirme com o PIN', 'Desconectar apaga os códigos deste aparelho.', function (v) { return v === pinGet(); }, function () {
          stopPlayer();
          store.del('ativa.mac'); store.del('ativa.key');
          loadDevice(true);
          showActivation('Aparelho desconectado. Estes são os códigos novos.', false);
        });
      });
    },
    security: function (b) {
      sInfo(b, 'lock', 'PIN', pinGet() === '0000' ? 'Padrão (0000) — troque!' : 'Personalizado');
      sAction(b, 'chpin', 'key', 'Alterar PIN', 'Pede o PIN atual, o novo e a confirmação.', function () {
        askPin('PIN atual', '', function (v) { return v === pinGet(); }, function () {
          askPin('Novo PIN', 'Escolha 4 números (0000 não vale).', function (v) { return v !== '0000'; }, function (nv) {
            askPin('Confirme o novo PIN', '', function (v) { return v === nv; }, function () { store.set('ativa.pin', nv); toast('PIN alterado'); redraw(); });
          });
        });
      });
      sInfo(b, 'chip', 'Endereço MAC', D.mac);
    },
    parental: function (b) {
      sToggle(b, 'parental', 'Ativar controle parental', 'Esconde conteúdo +18 e exige o PIN nas pastas bloqueadas. Desligar pede o PIN.', SET.parental, function () {
        if (SET.parental) { askPin('Digite o PIN', 'Para desligar o controle parental.', function (v) { return v === pinGet(); }, function () { set('parental', false); redraw(); }); }
        else { set('parental', true); S.unlocked = false; S.items = {}; redraw(); }
      });
      sToggle(b, 'unlock', 'Liberado nesta sessão', S.unlocked ? 'Liberado até fechar o app.' : 'Digite o PIN para liberar até fechar o app.', S.unlocked, function () {
        if (S.unlocked) { S.unlocked = false; S.items = {}; toast('Bloqueado de novo'); redraw(); }
        else { withPin('Liberar conteúdo nesta sessão.', function () { S.items = {}; toast('Liberado até fechar o app'); redraw(); }); }
      });
      sHint(b, 'PIN padrão: 0000. Troque em Segurança → Alterar PIN.');
    },
    restrict: function (b) {
      sChoice(b, 'window', 'Horário do controle parental', null, [['always', 'Sempre'], ['night', 'Só à noite (22h às 6h)']], SET.window, function (v) { set('window', v); redraw(); });
      var g = mk('div', 'sgroup');
      g.appendChild(mk('b', null, 'Pastas de canais bloqueadas'));
      g.appendChild(mk('small', null, 'As marcadas pedem o PIN para abrir.'));
      b.appendChild(g);
      catToggleList(b, 'live', SET.blocked, 'blocked');
    },
    playback: function (b) {
      sChoice(b, 'quality', 'Qualidade predefinida', 'Abre os canais nesta qualidade quando existir. No player, OK troca na hora.',
        [['best', 'A melhor'], ['uhd', '4K'], ['fhd265', 'FHD H265'], ['fhd', 'FHD'], ['hd', 'HD'], ['sd', 'SD']], SET.quality, function (v) { set('quality', v); setJson('ativa.vq', {}); redraw(); });
      sToggle(b, 'failover', 'Mudança automática em caso de falha', 'Se o canal travar, o app troca sozinho de resolução ou formato.', SET.failover, function () { set('failover', !SET.failover); redraw(); });
      if (SET.failover) { sChoice(b, 'failWait', 'Espera antes de mudar', null, [[10, '10s'], [15, '15s'], [20, '20s'], [30, '30s']], SET.failWait, function (v) { set('failWait', v); redraw(); }, true); }
      sToggle(b, 'resumeLast', 'Retomar o último canal ao abrir', null, SET.resumeLast, function () { set('resumeLast', !SET.resumeLast); redraw(); });
      sChoice(b, 'infoBar', 'Duração da barra de informação', null, [[3, '3s'], [5, '5s'], [8, '8s']], SET.infoBar, function (v) { set('infoBar', v); redraw(); }, true);
      sChoice(b, 'format', 'Formato do fluxo preferencial', null, [['hls', 'HLS (.m3u8)'], ['ts', 'TS']], SET.format, function (v) { set('format', v); redraw(); }, true);
      sChoice(b, 'sleep', 'Temporizador para dormir', 'Desliga o vídeo sozinho depois do tempo escolhido.', [[0, 'Desligado'], [30, '30 min'], [60, '1 h'], [90, '1h30'], [120, '2 h']], S.sleepMin || 0, function (v) {
        S.sleepMin = v;
        if (sleepTimer) { clearTimeout(sleepTimer); sleepTimer = 0; }
        if (v) { sleepTimer = setTimeout(function () { stopPlayer(); toast('Temporizador: vídeo desligado'); S.sleepMin = 0; }, v * 60000); toast('O vídeo desliga em ' + v + ' minutos'); }
        else { toast('Temporizador desligado'); }
        redraw();
      }, true);
    },
    present: function (b) {
      sChoice(b, 'accent', 'Cor de destaque', null, [['orange', 'Laranja AtivaPlays'], ['blue', 'Azul'], ['purple', 'Roxo']], SET.accent, function (v) { setAccent(v); redraw(); }, true);
      sChoice(b, 'clock24', 'Formato da hora', null, [[true, '24 horas'], [false, '12 horas']], SET.clock24, function (v) { set('clock24', v); tickClock(); redraw(); }, true);
      sChoice(b, 'showDate', 'Data sob a hora', null, [[true, 'Visível'], [false, 'Oculta']], SET.showDate, function (v) { set('showDate', v); tickClock(); redraw(); }, true);
      sToggle(b, 'hideAdult', 'Ocultar conteúdo para adultos (+18)', 'Desligar pede o PIN.', SET.hideAdult, function () {
        if (SET.hideAdult) { askPin('Digite o PIN', 'Para mostrar conteúdo +18.', function (v) { return v === pinGet(); }, function () { set('hideAdult', false); S.items = {}; redraw(); }); }
        else { set('hideAdult', true); S.items = {}; redraw(); }
      });
      sChoice(b, 'chNumbers', 'Números dos canais', null, [[true, 'Do provedor'], [false, 'Ocultar']], SET.chNumbers, function (v) { set('chNumbers', v); redraw(); }, true);
      sToggle(b, 'origOrder', 'Ordem original da lista', 'Desligado: as pastas mais assistidas aparecem primeiro.', SET.origOrder, function () { set('origOrder', !SET.origOrder); redraw(); });
    },
    data: function (b) {
      sAction(b, 'reload', 'refresh', 'Recarregar a lista', 'Baixa canais, filmes e séries de novo.', function () { stopPlayer(); toast('Recarregando…'); S.wantMain = true; enterApp(true); });
      sAction(b, 'cache', 'cloud', 'Limpar cache', 'Apaga as pastas guardadas na memória e recarrega.', function () { S.items = {}; S.loading = {}; toast('Cache limpo'); S.wantMain = true; enterApp(true); });
    },
    history: function (b) {
      var w = watchAll(), mv = 0, ep = 0, i;
      for (i = 0; i < w.length; i++) { if (w[i].type === 'episode') { ep++; } else { mv++; } }
      sAction(b, 'hch', 'tv', 'Limpar histórico de canais', recents().length + ' canal(is)', function () { setJson(pk('recent'), []); store.del(pk('lastlive')); toast('Histórico de canais limpo'); redraw(); });
      sAction(b, 'hmv', 'film', 'Limpar histórico de filmes', mv + ' filme(s)', function () { setJson(pk('watch'), w.filter(function (x) { return x.type === 'episode'; })); toast('Histórico de filmes limpo'); redraw(); });
      sAction(b, 'hse', 'layers', 'Limpar histórico de séries', ep + ' episódio(s)', function () { setJson(pk('watch'), w.filter(function (x) { return x.type !== 'episode'; })); toast('Histórico de séries limpo'); redraw(); });
    },
    favs: function (b) {
      var f = favs(), c = { live: 0, movie: 0, series: 0 }, i;
      for (i = 0; i < f.length; i++) { c[f[i].type] = (c[f[i].type] || 0) + 1; }
      function clr(type) { return function () { setJson(pk('fav'), favs().filter(function (x) { return x.type !== type; })); text($('fav-count'), favs().length); toast('Favoritos apagados'); redraw(); }; }
      sAction(b, 'fch', 'tv', 'Apagar canais favoritos', c.live + ' canal(is)', clr('live'));
      sAction(b, 'fmv', 'film', 'Apagar filmes favoritos', c.movie + ' filme(s)', clr('movie'));
      sAction(b, 'fse', 'layers', 'Apagar séries favoritas', c.series + ' série(s)', clr('series'));
    },
    cats: function (b) {
      sChoice(b, 'catTab', 'Mostrar pastas de', 'As desmarcadas somem do app (não apaga nada da lista).', [['live', 'Canais'], ['movies', 'Filmes'], ['series', 'Séries']], SETS.catTab, function (v) { SETS.catTab = v; redraw(); }, true);
      catToggleList(b, SETS.catTab, SET.hidden, 'hidden', true);
    },
    about: function (b) {
      var ua = navigator.userAgent, dev = /Web0S|webOS/i.test(ua) ? 'LG webOS' : /Tizen/i.test(ua) ? 'Samsung Tizen' : 'Navegador';
      var cv = /Chrome\/(\d+)/.exec(ua);
      sInfo(b, 'tv', 'Aparelho', dev + (cv ? ' · motor ' + cv[1] : ''));
      sInfo(b, 'grid', 'Tela', window.innerWidth + ' × ' + window.innerHeight);
      sInfo(b, 'list', 'Lista', S.mode === 'm3u' ? 'Lista M3U' : S.mode === 'xtream' ? 'Painel Xtream' : 'Nenhuma');
      sInfo(b, 'info', 'Versão do app', CFG.VERSION || '3.1.0');
      var rt = sAction(b, 'ping', 'cloud', 'Testar conexão', 'Mede o tempo de resposta do servidor.', function () {
        var t0 = Date.now(), small = rt.querySelector('small');
        text(small, 'Testando…');
        api('session', {}, function () { text(small, 'Respondeu em ' + (Date.now() - t0) + ' ms'); }, function (m) { text(small, m); });
      });
      var g = mk('div', 'sgroup qr-row'), qr = mk('div', 'qr sm'), im = mk('img');
      im.src = 'qr-whatsapp.png'; qr.appendChild(im); g.appendChild(qr);
      var t = mk('div'); t.appendChild(mk('b', null, 'Suporte')); t.appendChild(mk('p', 'shint', 'Ativações, recarga de créditos e problemas.'));
      t.appendChild(mk('b', 'wa-num', SUPORTE)); g.appendChild(t);
      b.appendChild(g);
      sHint(b, 'Controle: setas andam · OK abre · segurar OK favorita · Voltar volta · no player, OK abre opções e qualidade.');
      sAction(b, 'restart', 'refresh', 'Reiniciar o app', null, function () { location.reload(); });
    }
  };
  /** Lista de pastas com chave liga/desliga (bloqueadas ou ocultas). */
  function catToggleList(body, tab, map, field, inverse) {
    var cats = S.cats[tab] || [], holder = mk('div', 'sopts');
    body.appendChild(holder);
    if (!cats.length) { holder.appendChild(mk('p', 'shint', 'Nenhuma pasta.')); return; }
    longList(holder, cats, function (c) {
      var k = catKey(tab, c), r = mk('button', 'f srow');
      var lab = mk('div', 'lab'); lab.appendChild(mk('b', null, c.name)); r.appendChild(lab);
      var val = inverse ? !map[k] : !!map[k];
      r.appendChild(mk('span', 'toggle' + (val ? ' yes' : '')));
      r.setAttribute('data-k', field + ':' + k); r._key = field + ':' + k;
      r.onclick = function () {
        var go = function () {
          if (map[k]) { delete map[k]; } else { map[k] = true; }
          saveSet(); S.items = {};
          var tg = r.querySelector('.toggle'), now = inverse ? !map[k] : !!map[k];
          if (now) { on(tg, 'yes'); } else { off(tg, 'yes'); }
        };
        if (field === 'blocked' && map[k]) { withPin('Para desbloquear esta pasta.', go); } else { go(); }
      };
      return r;
    }, { exit: { left: function () { return qs('#set-menu .smi.sel'); } } });
  }

  // ================================================================ ATIVAÇÃO
  var pollTimer = 0;
  function showActivation(msg, bad) {
    showScreen('activate');
    text($('act-mac'), D.mac);
    text($('act-key'), prettyKey(D.key));
    var st = $('act-status');
    text(st, msg || '');
    off(st, 'bad'); off(st, 'ok');
    if (msg) { on(st, bad ? 'bad' : 'ok'); }
    focusFirst(qs('[data-act="check"]'));
    if (pollTimer) { clearInterval(pollTimer); }
    pollTimer = setInterval(function () { checkSession(true); }, 25000);
  }
  function statusText(status) {
    if (status === 'expired') { return 'Seu acesso venceu. Peça a renovação e aperte “Já ativei, continuar”.'; }
    if (status === 'blocked') { return 'Este aparelho está bloqueado. Fale com quem vende o seu acesso.'; }
    if (status === 'not_registered') { return 'Este aparelho ainda não foi liberado. Passe os códigos abaixo e aperte “Já ativei, continuar”.'; }
    return 'Não foi possível liberar o acesso agora.';
  }
  function checkSession(quiet) {
    if (!quiet) { text($('act-status'), 'Verificando…'); off($('act-status'), 'bad'); }
    api('session', {}, function (r) {
      S.mode = r.mode || 'none'; S.name = r.name || ''; S.expires = r.expires_at || ''; S.status = r.status || '';
      if (!r.ok) { showActivation(statusText(r.status), true); return; }
      if (pollTimer) { clearInterval(pollTimer); pollTimer = 0; }
      enterApp(false);
    }, function (msg, body) {
      if (body && body.status) { showActivation(statusText(body.status), true); return; }
      if (quiet && !has($('boot'), 'on')) { return; }
      showActivation(msg, true);
    });
  }

  // ================================================================ ENTRAR
  /** Carrega o catálogo. Na primeira vez mostra os perfis enquanto carrega. */
  function enterApp(reload) {
    S.items = {}; S.loading = {}; S.liveCat = null; S.catalogReady = false;
    if (S.mode !== 'm3u' && S.mode !== 'xtream') { showActivation('Nenhuma lista cadastrada para este aparelho ainda.', true); return; }
    if (reload) { showScreen('boot'); text($('boot-msg'), 'Carregando o catálogo…'); } else { S.wantMain = false; showProfiles(); }
    var ready = function () {
      S.catalogReady = true;
      if (S.wantMain || reload) { S.wantMain = false; openMain(); }
    };
    if (S.mode === 'm3u') { loadM3uCatalog(ready); } else { loadXtreamCategories(ready); }
  }
  function openMain() {
    S.wasInMain = true;
    showScreen('main');
    text($('fav-count'), favs().length);
    setView('home');
    if (SET.resumeLast && !S.resumed) {
      S.resumed = true;
      var last = getJson(pk('lastlive'), null);
      if (last) { openItem(last, null); }
    }
  }
  function loadXtreamCategories(ready) {
    api('categories', {}, function (r) {
      S.cats.live = r.live || []; S.cats.movies = r.movies || []; S.cats.series = r.series || [];
      if (!S.cats.live.length && !S.cats.movies.length && !S.cats.series.length) { bootFail('A lista não devolveu nenhuma pasta. Confira os dados da lista no painel.'); return; }
      ready();
    }, bootFail);
  }
  function loadM3uCatalog(ready) {
    api('catalog', {}, function (r) {
      function toCats(secs) {
        var out = [], i, j;
        for (i = 0; i < secs.length; i++) {
          var its = secs[i].items || [];
          for (j = 0; j < its.length; j++) { if (its[j].type === 'live' && !its[j].num) { its[j].num = j + 1; } }
          out.push({ id: secs[i].id, name: secs[i].name, items: its });
        }
        return out;
      }
      S.cats.live = toCats(r.live || []); S.cats.movies = toCats(r.movies || []); S.cats.series = toCats(r.series || []);
      ready();
    }, bootFail);
  }
  function bootFail(msg) {
    showScreen('boot');
    text($('boot-msg'), msg + '  —  aperte OK para tentar de novo.');
    var retry = function (e) {
      var k = keyName(e);
      if (k !== 'ok' && k !== 'back') { return; }
      document.removeEventListener('keyup', retry, true);
      text($('boot-msg'), 'Tentando de novo…');
      checkSession(true);
    };
    document.addEventListener('keyup', retry, true);
  }

  // ================================================================ LIGA TUDO
  function setAccent(name) {
    document.body.className = 'accent-' + name;
    SET.accent = name; saveSet();
    var dots = list(qsa('.dot')), i;
    for (i = 0; i < dots.length; i++) { if (dots[i].getAttribute('data-accent') === name) { on(dots[i], 'sel'); } else { off(dots[i], 'sel'); } }
  }
  function tickClock() {
    var d = new Date();
    text($('clock-time'), fmtTime(d.getHours(), d.getMinutes()));
    text($('clock-date'), SET.showDate ? two(d.getDate()) + '/' + two(d.getMonth() + 1) : '');
  }
  function wireButtons() {
    var navs = list(qsa('#main [data-view]')), i;
    for (i = 0; i < navs.length; i++) { (function (b) { b.onclick = function () { setView(b.getAttribute('data-view')); }; })(navs[i]); }
    var dots = list(qsa('.dot')), j;
    for (j = 0; j < dots.length; j++) { (function (b) { b.onclick = function () { setAccent(b.getAttribute('data-accent')); }; })(dots[j]); }
    $('hero-play').onclick = function () { if (S.heroItem) { openItem(S.heroItem); } };
    $('hero-fav').onclick = function () { if (S.heroItem) { toggleFav(S.heroItem); setHero(S.heroItem); } };
    qs('[data-act="check"]').onclick = function () { checkSession(false); };
    qs('[data-act="new"]').onclick = function () { loadDevice(true); showActivation('Códigos novos gerados. Passe-os para quem vende o seu acesso.', false); };
    qs('[data-act="do-search"]').onclick = function () { openKeyboard('Buscar', S.lastQ || '', function (q) { S.lastQ = q; doSearch(q); }); };
    var reloads = list(qsa('[data-act="reload"]')), r;
    for (r = 0; r < reloads.length; r++) { reloads[r].onclick = function () { stopPlayer(); toast('Recarregando…'); enterApp(true); }; }
    $('prof-edit').onclick = toggleProfEdit;
    // Campo de busca: vira botão que abre o teclado do controle (campo de texto prende as setas).
    var si = $('search-input'), sb = mk('button', 'f search-input', 'Aperte OK para escrever');
    sb.id = 'search-input';
    si.parentNode.replaceChild(sb, si);
    sb.onclick = function () { openKeyboard('Buscar', S.lastQ || '', function (q) { S.lastQ = q; doSearch(q); }); };
  }
  function fitScreen() {
    var w = window.innerWidth || 1920;
    document.documentElement.style.fontSize = (16 * w / 1920) + 'px';
    if (P.mode === 'mini') { placeMini(); }
  }
  function start() {
    fitScreen();
    window.addEventListener('resize', fitScreen);
    paintIcons(document);
    setAccent(SET.accent || 'orange');
    setupObserver();
    loadDevice(false);
    wirePlayer();
    wireButtons();
    registerTvKeys();
    tickClock();
    setInterval(tickClock, 30000);
    document.addEventListener('keydown', onKeyDown, true);
    document.addEventListener('keyup', onKeyUp, true);
    text($('boot-msg'), 'Conectando…');
    if (!CFG.SUPABASE_URL || !CFG.SUPABASE_ANON_KEY) { text($('boot-msg'), 'Falta configurar o arquivo config.js.'); return; }
    // Dentro do APK de Android TV: usa o MESMO MAC/chave do app Android
    // (o cliente que já ativou não precisa ativar de novo).
    if (window.AtivaBridge) {
      var go = false;
      var proceed = function () { if (go) { return; } go = true; checkSession(true); };
      window.__setDevice = function (mac, key) {
        if (/^[0-9A-F]{2}(:[0-9A-F]{2}){5}$/.test(mac) && /^[0-9a-f]{12}$/.test(key)) {
          D.mac = mac; D.key = key; store.set('ativa.mac', mac); store.set('ativa.key', key);
        }
        proceed();
      };
      try { window.AtivaBridge.postMessage('device'); } catch (e) {}
      setTimeout(proceed, 2500);
    } else {
      checkSession(true);
    }
    setTimeout(function () { if (has($('boot'), 'on')) { showActivation('Sem resposta do servidor. Confira a internet da TV.', true); } }, 50000);
  }

  /* Teclas vindas do APK de Android TV (o controle chega primeiro no Android,
     que repassa para cá). Se a mesma tecla também chegar direto na página,
     a repetida em menos de 150 ms é ignorada. */
  var lastKey = { code: 0, up: false, t: 0, src: '' };
  function dedupe(code, up, src) {
    var now = Date.now();
    if (lastKey.code === code && lastKey.up === up && lastKey.src !== src && now - lastKey.t < 150) { return true; }
    lastKey = { code: code, up: up, t: now, src: src };
    return false;
  }
  window.__tvKey = function (code, up) {
    if (dedupe(code, !!up, 'host')) { return; }
    var e = { keyCode: code, isTrusted: true, preventDefault: function () {}, stopPropagation: function () {} };
    if (up) { onKeyUp(e); } else { onKeyDown(e); }
  };

  // Teste no navegador do PC: ?demo=1 usa um catálogo de exemplo (com canais em várias qualidades).
  if (/[?&]demo=1/.test(location.search)) {
    api = function (action, params, done) {
      setTimeout(function () {
        if (action === 'session') { done({ ok: true, status: 'active', mode: 'xtream', name: 'Demo', expires_at: '2027-12-31' }); return; }
        if (action === 'categories') {
          var mkc = function (p, n, nm) { var a = [], i; for (i = 1; i <= n; i++) { a.push({ id: p + i, name: nm + i }); } return a; };
          var live = mkc('l', 30, 'Canais | Pasta ');
          live.unshift({ id: 'l0', name: 'Canais | Abertos' });
          done({ live: live, movies: mkc('m', 12, 'Filmes | Pasta '), series: mkc('s', 8, 'Séries | Pasta ') }); return;
        }
        if (action === 'streams') {
          var out = [], i, q;
          if (params.category_id === 'l0') {
            var bases = ['Globo SP', 'SBT', 'Record TV', 'Band', 'RedeTV'], quals = ['SD', 'HD', 'FHD', 'FHD ALT', 'H265', 'H265 ALT', 'FHD H265'];
            for (i = 0; i < bases.length; i++) { for (q = 0; q < quals.length; q++) { out.push({ id: 'lv-' + i + '-' + q, sid: i + '' + q, type: 'live', title: bases[i] + ' ' + quals[q], logo: null, url: 'about:blank#' + quals[q] }); } }
            out.push({ id: 'lv-x', sid: 'x', type: 'live', title: 'Canal Único', logo: null, url: 'about:blank' });
            done({ items: out }); return;
          }
          var n = params.type === 'live' ? 400 : 80;
          for (i = 1; i <= n; i++) {
            out.push({ id: params.type + '-' + params.category_id + '-' + i, sid: String(i), type: params.type,
              title: (params.type === 'live' ? 'Canal ' : params.type === 'series' ? 'Série ' : 'Filme ') + params.category_id + '-' + i,
              logo: null, rating: params.type === 'live' ? '' : String((i % 9) + 1), url: 'about:blank' });
          }
          done({ items: out }); return;
        }
        if (action === 'epg') { done({ now: 'Programa de exemplo', start: '2026-01-01 10:00:00', end: '2026-01-01 11:00:00', next: 'Próximo programa' }); return; }
        done({});
      }, 120);
    };
  }

  if (document.readyState === 'complete' || document.readyState === 'interactive') { start(); }
  else { document.addEventListener('DOMContentLoaded', start); }
})();
